package com.daimler.parking.circuitbreaker;
//package com.daimler.ammi.circuitbreaker;
//
//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//@Service
//public class AmmiCircuitBreakerService {
//
//	@Value("${ammi.viewparkingspace.endpoint}")
//	private String viewParkingEndpoint;
//
//	@HystrixCommand(fallbackMethod = "defaultParkingSpaceList")
//	public String getParkingSpaceList() {
//
//		return new RestTemplate().getForObject(viewParkingEndpoint, String.class);
//	}
//
//	@SuppressWarnings("unused")
//	private String defaultParkingSpaceList(String parkingSpace) {
//		return "Sorry, we don't have space for you!!";
//	}
//}
