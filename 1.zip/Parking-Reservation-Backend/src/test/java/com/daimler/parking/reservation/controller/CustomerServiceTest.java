package com.daimler.parking.reservation.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.request.CancellationRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.applicationinsights.core.dependencies.http.HttpStatus;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=ParkingSpaceBackendApplication.class)
@WebAppConfiguration
public class CustomerServiceTest {
	
	private MockMvc mockMvc;

    @Autowired
    private RestTemplate restTemplate;
    
    @InjectMocks
	private CustomerService customerService;

	@Mock
	private C2CManager c2cmanager;

	@Mock
	private AmpidoAdapter ampidoAdapter;

	@Mock
	private BaseResponse cancelResponse;

	private MockMvc mvc;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mvc = MockMvcBuilders.standaloneSetup(customerService).build();
	}

	@Test
	public void testcancelBooking() throws Exception {
		Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);

		CancellationRequest cancellationRequest = new CancellationRequest();
		cancellationRequest.setBookingId("123");
		cancellationRequest.setCancelReason("Some reason");
		final String auth1 = "Basic c3VwcG9ydE1hbmFnZXI6c3VwcG9ydE1hbmFnZXJAMTIz";
		
		
		Mockito.when(ampidoAdapter.cancelReservedParkingSpace(cancellationRequest)).thenReturn(cancelResponse);

		ResponseEntity<BaseResponse> cancelResponseEntity = customerService.cancelBooking(cancellationRequest, auth1);
//		System.out.println(cancelResponseEntity.getStatusCode());
		
		String url1 = "/c2creservation/v1/cac/cancel";
		String url2 = "/c2creservation/v1/cac/cancel/12345";

		 ObjectMapper mapper = new ObjectMapper();
		 String request = mapper.writeValueAsString(cancellationRequest);
//		mvc.perform(delete(url1).header("Authorization", "Basic c3VwcG9ydE1hbmFnZXI6c3VwcG9ydE1hbmFnZXJAMTIz")).andExpect(status().is(422));
		mvc.perform(delete(url2).content(request).header("Authorization", "Basic c3VwcG9ydE1hbmFnZXI6c3VwcG9ydE1hbmFnZXJAMTIz"))
						.andExpect(status().is4xxClientError());

	}


}
