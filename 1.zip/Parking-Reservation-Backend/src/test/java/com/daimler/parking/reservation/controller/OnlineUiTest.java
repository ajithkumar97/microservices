/**
 * Copyright 2017 Mercedes Benz Research & Development, A Daimler Company. All rights reserved.
 */

package com.daimler.parking.reservation.controller;

import com.daimler.parking.reservation.services.OnlineUiService;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @author patilve
 *
 */
public class OnlineUiTest {
    // ***************************************************************************************************************
    // ******************************************** Public Fields ****************************************************
    // ***************************************************************************************************************

    // ***************************************************************************************************************
    // ****************************************** Non Public Fields **************************************************
    // ***************************************************************************************************************

    private MockMvc mvc;

    @InjectMocks
    private OnlineUi onlineUi;

    @Mock
    OnlineUiService onlineUiService;

    // ***************************************************************************************************************
    // *********************************************** Constructors **************************************************
    // ***************************************************************************************************************
    @Before
    public void setup() {
        MockitoAnnotations.initMocks( this );
        this.mvc = MockMvcBuilders.standaloneSetup( onlineUi ).build();
    }

    // ***************************************************************************************************************
    // ******************************************** Public Methods ***************************************************
    // ***************************************************************************************************************
    @Test
    public void testGetsequence0() throws Exception {
        final String url = "/c2creservation/v1/ntg/booking/sequence/0";
        mvc.perform( get( url ) ).andExpect( status().is2xxSuccessful() );

    }
    // ***************************************************************************************************************
    // ****************************************** Non Public Methods *************************************************
    // ***************************************************************************************************************
}
