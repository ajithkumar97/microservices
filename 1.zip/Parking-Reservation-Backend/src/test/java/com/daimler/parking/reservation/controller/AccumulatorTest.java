/*package com.daimler.parking.reservation.controller;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.ParkingSpaceResponse;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ParkingSpaceBackendApplication.class)
@WebAppConfiguration
public class AccumulatorTest {

	@InjectMocks
	private Accumulator accumulator;

	@Mock
	private C2CManager c2cmanager;

	@Mock
	private AmpidoAdapter ampidoAdapter;

	@Mock
	private ParkingSpaceResponse parkingSpaceResponse;

	@Mock
	private ParkingSpaceListResponse parkingSpaceListResponse;

	private MockMvc mvc;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mvc = MockMvcBuilders.standaloneSetup(accumulator).build();
	}

	@Test
	public void testGetParkingSpaceList() throws Exception {
		Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);

		final double latitudeTopLeft = 48.138547;
		final double longitudeTopLeft = 48.138547;
		final double latitudeBottomRight = 48.138547;
		final double longitudeBottomRight = 11.5859380;
		final String startTime = "2017-08-26T11:05:55.312Z";
		final String endTime = "2017-08-26T12:05:55.312Z";
		final String auth = "Basic bnRnbWFuYWdlcjpudGdtYW5hZ2VyITIz";

		Mockito.when(ampidoAdapter.getParkingListFromAmpido(latitudeTopLeft, longitudeTopLeft, latitudeBottomRight,
				longitudeBottomRight, startTime, endTime)).thenReturn(parkingSpaceListResponse);

		parkingSpaceListResponse = accumulator.getParkingSpaceList(latitudeTopLeft, longitudeTopLeft,
				latitudeBottomRight, longitudeBottomRight, startTime, endTime,auth);
		assertNotNull(parkingSpaceListResponse);
		System.out.println(parkingSpaceListResponse.getParkingSpaces().size());

		String url1 = "/c2creservation/v1/accumulator/parkinglist";

		mvc.perform(get(url1)).andExpect(status().isBadRequest());
		mvc.perform(get(url1).param("latitudeTopLeft", "48.138547").param("longitudeTopLeft", "11.572228")
				.param("latitudeBottomRight", "48.132827").param("longitudeBottomRight", "11.5859380")
				.param("startTime", "2017-08-19T09:45:00.000Z")).andExpect(status().isOk());
		mvc.perform(get(url1).param("latitudeTopLeft", "48.138547").param("latitudeBottomRight", "48.132827")
				.param("longitudeBottomRight", "11.5859380").param("startTime", "2017-08-19T09:45:00.000Z"))
				.andExpect(status().isBadRequest());
		mvc.perform(get(url1).param("latitudeTopLeft", "48.138547").param("latitudeBottomRight", "48.132827")
				.param("longitudeBottomRight", "11.5859380").param("startTime", "abc"))
				.andExpect(status().isBadRequest());

	}

	@Test
	public void testGetParkingSpace() throws Exception {
		
		Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);
		
		final String uuid= "VMjEZKXLoyKX9DN1";
		final String startTime="2017-07-26T11:05:55.312Z";
		final String endTime = "2017-07-26T14:05:55.312Z";
		
		
		Mockito.when(ampidoAdapter.getParkingSpace(uuid,startTime,endTime)).thenReturn(parkingSpaceResponse);
		
		parkingSpaceResponse = accumulator.getParkingSpace(uuid,startTime,endTime);
		
		assertNotNull(parkingSpaceResponse);
		
		String url1 = "/c2creservation/v1/accumulator/parkingSpace/{uuid}";
		mvc.perform(get("/c2creservation/v1/accumulator/parkingSpace/{uuid}",7)).andExpect(status().isOk());
				
	}
	

}
*/