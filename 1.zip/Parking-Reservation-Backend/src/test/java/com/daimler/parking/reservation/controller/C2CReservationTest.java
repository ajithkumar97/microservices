package com.daimler.parking.reservation.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.handler.C2CBookingHandler;
import com.daimler.parking.reservation.handler.CpdHandler;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.Rent;
import com.daimler.parking.reservation.model.VehicleDetails;
import com.daimler.parking.reservation.request.RentRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.services.CIAMService;
import com.daimler.parking.reservation.services.NotificationService;
import com.daimler.parking.reservation.services.ParkingTransactionHistoryService;
import com.daimler.parking.reservation.services.PaymentService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=ParkingSpaceBackendApplication.class)
@WebAppConfiguration
public class C2CReservationTest {
    
    private MockMvc mockMvc;

    @Mock
    private C2CManager c2cmanager;
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private CIAMService ciamService;
    
    @Mock
    private AmpidoAdapter ampidoAdapter;
    
    @Mock
    private C2CBookingHandler c2cBookingHandler;
    
    @Mock
    private NotificationService notificationService;
    
    @Mock
    private PaymentService paymentService;
    
    @Mock
    private ParkingTransactionHistoryService parkingTransactionHistoryService;

    @InjectMocks
    private C2CReservation parkingReservationController;
    
    @InjectMocks
    private CpdHandler cpdHandler;

    
    @Test(expected=NullPointerException.class)
    public void testBookParkingSpace() throws Exception {
        
        Mockito.when(c2cmanager.getCiamService()).thenReturn(ciamService);
        
        Mockito.when(ciamService.isAuthorized(request)).thenReturn(true);
        
        
//      HttpHeaders httpHeaders =Mockito.mock(HttpHeaders.class);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("CIAM_ID", "ciam001");
        RentRequest rentRequest = new RentRequest();  
        
        Rent rent = new Rent();
        rent.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        rent.setEndTime("2016-06-22'T'14:13:20.001'Z'");
        rent.setSlotUuid("Slot-123");
        rentRequest.setRent(rent);
    	final String auth = "Basic bnRnbWFuYWdlcjpudGdtYW5hZ2VyITIz";
    	
    	ResponseEntity<BaseResponse> bookingResponse = parkingReservationController.bookParkingSpace(rentRequest, request,auth);
        
        assertNotNull(bookingResponse);
        assertEquals("200", bookingResponse.getStatusCode());
        assertNotEquals("500",bookingResponse.getStatusCode());
        
        
        /*mockMvc.perform(
                post("/c2creservation/v1/book")
                        .contentType(MediaType.APPLICATION_JSON)
                        .headers(httpHeaders)
                        .content(asJsonString(bookingRequest)))
                .andExpect(status().isOk());*/
    }
    
    
/*
    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders
                .standaloneSetup(parkingReservationController)
                .addFilters(new CORSFilter())
                .build();
    }
    
    *//**

    @Test
    public void testBookParkingSpace() throws Exception {
        
        Mockito.when(c2cmanager.getCiamService()).thenReturn(ciamService);
        
        Mockito.when(ciamService.isAuthorized(request)).thenReturn(true);
        
        Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);
        
        BookingDetails bookingDetails = new BookingDetails();
        
        BookingRequest bookingRequest = new BookingRequest();
        bookingRequest.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        bookingRequest.setEndTime("2016-06-22'T'14:13:20.001'Z'");
        bookingRequest.setLicencePlate("2016-06-22'T'14:13:20.001'Z'");
        bookingRequest.setSlotId("Slot-123");
        
        Type parkingSlotType01 = new Type();
        parkingSlotType01.setId("1001");
        parkingSlotType01.setName("Garage");

        Feature parkingSlotFeature01 = new Feature();
        parkingSlotFeature01.setId("2001");
        parkingSlotFeature01.setName("EV loading station available");
        List<Feature> parkingFeautures = new ArrayList<Feature>();
        parkingFeautures.add(parkingSlotFeature01);

        ExclusiveFor parkingSlotExclusive01 = new ExclusiveFor();
        ExclusiveFor parkingSlotExclusive02 = new ExclusiveFor();
        parkingSlotExclusive01.setName("Mercedes Benz");
        parkingSlotExclusive02.setName("Smart");
        List<ExclusiveFor> parkingExclusives = new ArrayList<ExclusiveFor>();
        parkingExclusives.add(parkingSlotExclusive01);
        parkingExclusives.add(parkingSlotExclusive02);

        Image parkingSlotImage01 = new Image();
        parkingSlotImage01.setType("Mercesed Benz Parking slots");
        parkingSlotImage01
                .setUrl("http://images.all-free-download.com/images/graphiclarge/daisy_pollen_flower_220533.jpg");
        List<Image> parkingImages = new ArrayList<Image>();
        parkingImages.add(parkingSlotImage01);

        ParkingSlot parkingSlot = new ParkingSlot();
        parkingSlot.setType(parkingSlotType01);
        parkingSlot.setFeatures(parkingFeautures);
        parkingSlot.setExclusiveFor(parkingExclusives);
        parkingSlot.setImages(parkingImages);
        parkingSlot.setUuid("20170004");
        parkingSlot.setFreeUntil("Jun 20, 2017 9:13:42 AM");
        parkingSlot.setPriceFirstHour(1f);
        parkingSlot.setPriceTotal(2f);
        parkingSlot.setLatitude(48.7666667);
        parkingSlot.setLongitude(9.1833333);
        parkingSlot.setAccessMethod("barrier");
        parkingSlot.setAccessRestriction("Euro 6 vehicles only");
        parkingSlot.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
        parkingSlot.setDescription("It is a private parking lot");
        parkingSlot.setCountry("DEU");
        parkingSlot.setCity("Köln");
        parkingSlot.setPostalCode("50679");
        parkingSlot.setStreetName("Charles-de-Gaulle-Platz");
        parkingSlot.setStreetNumber("1 - 3");

        Barrier barrier01 = new Barrier();
        barrier01.setUuid("2017003");
        barrier01.setPosition("Inlet");
        Barrier barrier02 = new Barrier();
        barrier02.setUuid("2017003");
        barrier02.setPosition("Inlet");

        List<Barrier> barriers = new ArrayList<Barrier>();
        barriers.add(barrier01);
        barriers.add(barrier02);
        
        bookingDetails.setCiamId("CIAM-123");
        bookingDetails.setUuid("Slot-123");
        bookingDetails.setBarriers(barriers);
        bookingDetails.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        bookingDetails.setEndTime("2016-06-24'T'14:13:20.001'Z'");
        bookingDetails.setLicenceplate("KA04JH1793");
        bookingDetails.setParkingSlot(parkingSlot);
        bookingDetails.setStatusCode("200");
        bookingDetails.setStatusMessage("Parking Reservation is done successfully without errors.");
        
        Mockito.when(ampidoAdapter.bookParkingSpace(bookingRequest)).thenReturn(bookingDetails);
        
        PaymentRequest paymentRequest = new PaymentRequest();

        paymentRequest.setAccountHolderName("Mr. Sumit Ranjan");
        paymentRequest.setAccountNumber("99999999999999");
        paymentRequest.setExpiresDate("2016-06-24'T'14:13:20.001'Z'");
        
        PaymentResponse paymentResponse = new PaymentResponse();
        
        Mockito.when(c2cmanager.getC2CBookingHandler()).thenReturn(c2cBookingHandler);
        
        Mockito.when(c2cBookingHandler.getPaymentService()).thenReturn(paymentService);
        
        Mockito.when(paymentService.addOrder(paymentRequest)).thenReturn(paymentResponse);
        
        EventNotificationRequest notificationRequest = new EventNotificationRequest();
        ParkingGarageAddress address = new ParkingGarageAddress();
        address.setBuildingNo("B123");
        address.setCity("Munich");
        address.setCountry("Germany");
        address.setStreet("Munich Street");
        address.setZipcode("560066");
        notificationRequest.setDuration("2hrs");
        notificationRequest.setEndDateTime("06/16/2017");
        notificationRequest.setEventType("local");
        notificationRequest.setFinId("F123");
        notificationRequest.setParkingFacilityName("Munich Facility");
        notificationRequest.setPrice("2$");
        notificationRequest.setStartDateTime("06/14/2017");
        notificationRequest.setUserId("U123");
        notificationRequest.setAddress(address);

        ParkingTransactionRequest parkingTxnReq = new ParkingTransactionRequest();

        parkingTxnReq.setBookingResponse(bookingDetails);
        parkingTxnReq.setServiceProvider("AMPIDO");
        
        EventNotificationResponse notificationResponse = new EventNotificationResponse();
        
        Mockito.when(c2cBookingHandler.getNotificationService()).thenReturn(notificationService);
        
        Mockito.when(notificationService.addNotification(notificationRequest)).thenReturn(notificationResponse);
        
        parkingTxnReq.setNotificationId("N-123");
        parkingTxnReq.setTxnID("T-123");
        
        ParkingBookingResponse parkingBookingResponse= new ParkingBookingResponse();
        
        Mockito.when(c2cBookingHandler.getParkingTransactionHistoryService()).thenReturn(parkingTransactionHistoryService);
        
        
        System.out.println( "Transaction Histoty Request" );
        
        Mockito.when(parkingTransactionHistoryService.addParkingTransactionHistory(parkingTxnReq)).thenReturn(parkingBookingResponse);
        
        mockMvc.perform(
                post("/c2creservation/v1/bookParkingSpace")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(bookingRequest)))
                .andExpect(status().isOk());
        
    }
    
    **//*
    
    @Test
    public void testGetParkingSpaceList() throws Exception {
        
        Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);

        
        ParkingResponse parkingSpaceResponse  = new ParkingResponse();
        
        ParkingSlot parkingSlot1 = new ParkingSlot();
        ParkingSlot parkingSlot2 = new ParkingSlot();
        ParkingSlot parkingSlot3 = new ParkingSlot();
        
        List<ParkingSlot> parkingSlots = new ArrayList<ParkingSlot>();
        
        Type parkingSlotType01 = new Type();
//      parkingSlotType01.setId("1001");
        parkingSlotType01.setName("Garage");

        Feature parkingSlotFeature01 = new Feature();
//      parkingSlotFeature01.setId("2001");
        parkingSlotFeature01.setName("EV loading station available");
        List<Feature> parkingFeautures = new ArrayList<Feature>();
        parkingFeautures.add(parkingSlotFeature01);

        ExclusiveFor parkingSlotExclusive01 = new ExclusiveFor();
        ExclusiveFor parkingSlotExclusive02 = new ExclusiveFor();
        parkingSlotExclusive01.setName("Mercedes Benz");
        parkingSlotExclusive02.setName("Smart");
        List<ExclusiveFor> parkingExclusives = new ArrayList<ExclusiveFor>();
        parkingExclusives.add(parkingSlotExclusive01);
        parkingExclusives.add(parkingSlotExclusive02);

        Image parkingSlotImage01 = new Image();
        parkingSlotImage01.setType("Mercesed Benz Parking slots");
        parkingSlotImage01.setUrl("http://images.all-free-download.com/images/graphiclarge/daisy_pollen_flower_220533.jpg");
        List<Image> parkingImages = new ArrayList<Image>();
        parkingImages.add(parkingSlotImage01);

        parkingSlot1.setType(parkingSlotType01);
        parkingSlot1.setFeatures(parkingFeautures);
        parkingSlot1.setExclusiveFor(parkingExclusives);
        parkingSlot1.setImages(parkingImages);
        parkingSlot1.setUuid("2017P0001");
        parkingSlot1.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        parkingSlot1.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
        parkingSlot1.setPriceTotal(2f);
        parkingSlot1.setLatitude(48.7666667);
        parkingSlot1.setLongitude(9.1833333);
        parkingSlot1.setAccessMethod("barrier");
        parkingSlot1.setAccessRestriction("Euro 6 vehivles only");
        parkingSlot1.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
        parkingSlot1.setDescription("It is a private parking lot");
        parkingSlot1.setCountry("DEU");
        parkingSlot1.setCity("Berlin");
        parkingSlot1.setPostalCode("50679");
        parkingSlot1.setStreetName("Romanshorner Weg");
        parkingSlot1.setStreetNumber("192");
        
        parkingSlot2.setType(parkingSlotType01);
        parkingSlot2.setFeatures(parkingFeautures);
        parkingSlot2.setExclusiveFor(parkingExclusives);
        parkingSlot2.setImages(parkingImages);
        parkingSlot2.setUuid("2017P0002");
        parkingSlot2.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        parkingSlot2.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
        parkingSlot2.setPriceTotal(3);
        parkingSlot2.setLatitude(46.520348);
        parkingSlot2.setLongitude(11.402354);
        parkingSlot2.setAccessMethod("barrier");
        parkingSlot2.setAccessRestriction("Euro 6 vehivles only");
        parkingSlot2.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
        parkingSlot2.setDescription("It is a private parking lot");
        parkingSlot2.setCountry("DEU");
        parkingSlot2.setCity("Berlin");
        parkingSlot2.setPostalCode("50539");
        parkingSlot2.setStreetName("Joachimsthaler Straßet");
        parkingSlot2.setStreetNumber("30");
        
        
        Feature parkingSlotFeature03 = new Feature();
//      parkingSlotFeature01.setId("2001");
        parkingSlotFeature03.setName("No EV loading station available");
        List<Feature> parkingFeautures03 = new ArrayList<Feature>();
        parkingFeautures03.add(parkingSlotFeature03);

        List<ExclusiveFor> parkingExclusives03 = new ArrayList<ExclusiveFor>();
        
        parkingExclusives03.add(parkingSlotExclusive01);
        
        parkingSlot3.setType(parkingSlotType01);
        parkingSlot3.setFeatures(parkingFeautures03);
        parkingSlot3.setExclusiveFor(parkingExclusives03);
        parkingSlot3.setImages(parkingImages);
        parkingSlot3.setUuid("2017P0003");
        parkingSlot3.setStartTime("2016-06-22'T'14:13:20.001'Z'");
        parkingSlot3.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
        parkingSlot3.setPriceTotal(2);
        parkingSlot3.setLatitude(46.7666667);
        parkingSlot3.setLongitude(9.1833333);
        parkingSlot3.setAccessMethod("barrier");
        parkingSlot3.setAccessRestriction("Euro 6 vehivles only");
        parkingSlot3.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
        parkingSlot3.setDescription("It is a private parking lot");
        parkingSlot3.setCountry("DEU");
        parkingSlot3.setCity("Berlin");
        parkingSlot3.setPostalCode("50679");
        parkingSlot3.setStreetName("Charles-de-Gaulle-Platz");
        parkingSlot3.setStreetNumber("13");
        
        parkingSlots.add(parkingSlot1);
        parkingSlots.add(parkingSlot2);
        parkingSlots.add(parkingSlot3);
        
        
        parkingSpaceResponse.setStatusCode("200");
        parkingSpaceResponse.setStatusMessage("Successful");
      //  parkingSpaceResponse.setErrors(null);
        parkingSpaceResponse.setParkingSlots(parkingSlots);
        
  
        
        
        
        Mockito.when(ampidoAdapter.getParkingSpaceList(48.7666667, 9.1833333, 48.7666667, 9.1833333,"2016-06-22'T'14:13:20.001'Z'" ,"2016-06-22'T'14:13:20.001'Z'"))
        .thenReturn(parkingSpaceResponse);
        
        
        
//         mockMvc.perform(MockMvcRequestBuilders.get("/parkingreservation/v1/accumulator/parkingSpaceList"
//                      +"?latitudeTopLeft=48.7666667&longitudeTopLeft=9.1833333&latitudeBottomRight=48.7666667&longitudeBottomRight=9.1833333&"
//                      +"startTime=2017-04-18T11:05:55.312Z&endTime=2017-04-18T11:05:55.312Z"))
//                      .andExpect(status().isOk());

            
    }
*/
      public static String asJsonString(final Object obj) {
            try {
                final ObjectMapper mapper = new ObjectMapper();
                return mapper.writeValueAsString(obj);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
      
      
      
      @Test(expected=NullPointerException.class)
      public void testGetLicensePlateInfo() throws Exception{
         
         final String finOrVin= "WDD2221631A160411";
      
         ResponseEntity<VehicleDetails> vehicleInfo = cpdHandler.getVehicleInfoWithFinOrVin(finOrVin);
         VehicleDetails vehicleDetails =new VehicleDetails();
         vehicleDetails.setFin("WDD2221631A160411");
         vehicleDetails.setVin(" ");
         vehicleDetails.setLicensePlate("S-PM-6030");
         
         String url = "/c2creservation/v1/getLicensePlate/{finOrVin}";
         
             mockMvc.perform(get(url)).andReturn().getResponse().equals(vehicleDetails);
         
      }


}
