var apikeyApp = angular.module('apikeyApp', [])
apikeyApp.factory('LoadSwaggerStatus', function() {
	return {
		load : 'false'
	};
});

apikeyApp.controller('apikeyController', function($scope, $http) {
	$scope.getApiKey = function(apiKeyValue) {
		$("#swagger-ui-container").html("");
		var host = document.location.origin;
		$http.get(host + "/swagger/getapikey?apikey=" + apiKeyValue).success(
				function(data) {
					$scope.apikey = data;
					$scope.load = data;
					if (data == true) {
						loadSwaggerUI();
					}
				})
	}

function loadSwaggerUI() {
		// Pre load translate...
		if (window.SwaggerTranslator) {
			window.SwaggerTranslator.translate();
		}
		var url = window.location.origin + "/apidoc";
		window.swaggerUi = new SwaggerUi(
				{
					url : url,
					dom_id : "swagger-ui-container",
					supportedSubmitMethods : [ 'get', 'post', 'put', 'delete',
							'patch' ],
					onComplete : function(swaggerApi, swaggerUi) {

						if (window.SwaggerTranslator) {
							window.SwaggerTranslator.translate();
						}

						$('pre code').each(function(i, e) {
							hljs.highlightBlock(e)
						});

						if ($scope.load == false) {
							$("#swagger-ui-container").html("");
						}
					},
					onFailure : function(data) {
						log("Unable to Load SwaggerUI");
					},
					docExpansion : "none",
					jsonEditor : false,
					apisSorter : "alpha",
					defaultModelRendering : 'schema',
					showRequestHeaders : false
				});

		window.swaggerUi.load();

		function log() {
			if ('console' in window) {
				console.log.apply(console, arguments);
			}
		}
	}
});