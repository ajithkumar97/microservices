package com.daimler.parking.reservation.onlineui.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReserveParkingSpaceButton
{
	@JsonProperty("Widgets")
	private List<Widgets> widgets;

	@JsonProperty("UID")
	private String uid;
	
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public List<Widgets> getWidgets() {
		return widgets;
	}

	public void setWidgets(List<Widgets> widgets) {
		this.widgets = widgets;
	}

	@Override
	public String toString() {
		return "ReserveParkingSpaceButton [uid=" + uid + ", widgets=" + widgets + "]";
	}		
}