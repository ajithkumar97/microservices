package com.daimler.parking.reservation.request;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;

public class BookingRequest extends BaseRequest implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 611838699138105348L;
	
	@NotEmpty(message = "Slot Id cannot be blank.")
	private String slotId;
	
	@NotEmpty(message = "startTime cannot be blank.")
	private String startTime;
	
	@NotEmpty(message = "endTime cannot be blank.")
	private String endTime;
	
	public String getSlotId() {
		return slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


}
