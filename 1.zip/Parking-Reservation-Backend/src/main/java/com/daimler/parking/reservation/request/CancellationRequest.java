package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;

public class CancellationRequest extends BaseRequest {

	@NotEmpty(message = "bookingId cannot be blank.")
	private String bookingId;
	
	@NotEmpty(message = "bookingId cannot be blank.")
	private String cancelReason;

	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	@Override
	public String toString() {
		return "CancellationRequest [bookingId=" + bookingId + ", cancelReason=" + cancelReason + "]";
	}

}
