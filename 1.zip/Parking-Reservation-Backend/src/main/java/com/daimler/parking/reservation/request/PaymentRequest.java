package com.daimler.parking.reservation.request;

import java.io.Serializable;
import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class PaymentRequest extends BaseRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Account Holder Name", readOnly = true)
	@JsonProperty("accountHolderName")
	@NotEmpty(message = "accountHolderName cannot be blank.")
	private String accountHolderName;
	
	@ApiModelProperty(value = "Account Number", readOnly = true)
	@JsonProperty("accountNumber")
	@NotEmpty(message = "accountNumber cannot be blank.")
	private String accountNumber;
	
	@ApiModelProperty(value = "Expiry Date od M-Pay card", readOnly = true)
	@JsonProperty("expiresDate")
	@NotEmpty(message = "expiresDate cannot be blank.")
	private String expiresDate;

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getExpiresDate() {
		return expiresDate;
	}

	public void setExpiresDate(String expiresDate) {
		this.expiresDate = expiresDate;
	}

}
