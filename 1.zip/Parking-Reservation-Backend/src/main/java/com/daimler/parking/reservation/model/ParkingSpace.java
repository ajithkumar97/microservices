package com.daimler.parking.reservation.model;

import org.hibernate.validator.constraints.NotEmpty;

public class ParkingSpace {
	
	@NotEmpty(message = "Slot Id cannot be blank.")
	private String parkingSpaceId;
	
	@NotEmpty(message = "latitude cannot be blank.")
	private double latitude;
	
	@NotEmpty(message = "longitude cannot be blank.")
	private double longitude;
	
	@NotEmpty(message = "country cannot be blank.")
	private String country;
	
	@NotEmpty(message = "city cannot be blank.")
	private String city;
	
	@NotEmpty(message = "streetName cannot be blank.")
	private String streetName;
	
	private String streetNumber;
	
	@NotEmpty(message = "postalCode cannot be blank.")
	private String postalCode;
	
	private String DetailsUrl;

	
	public String getParkingSpaceId() {
		return parkingSpaceId;
	}

	public void setParkingSpaceId(String parkingSpaceId) {
		this.parkingSpaceId = parkingSpaceId;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getDetailsUrl() {
		return DetailsUrl;
	}

	public void setDetailsUrl(String detailsUrl) {
		DetailsUrl = detailsUrl;
	}

	@Override
	public String toString() {
		return "ParkingSpace [parkingSpaceId=" + parkingSpaceId + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", country=" + country + ", city=" + city + ", streetName=" + streetName + ", streetNumber="
				+ streetNumber + ", postalCode=" + postalCode + ", DetailsUrl=" + DetailsUrl + "]";
	}
	
}
