package com.daimler.parking.reservation.onlineui.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Events
{
	@JsonProperty("ElementName")
	private String elementName;
	
	@JsonProperty("Type")
	private String type;

	@JsonProperty("Actions")
	private List<Actions> actions;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Actions> getActions() {
		return actions;
	}

	public void setActions(List<Actions> actions) {
		this.actions = actions;
	}

	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	@Override
	public String toString() {
		return "Events [type=" + type + ", actions=" + actions + ", elementName=" + elementName + "]";
	}	 
}
