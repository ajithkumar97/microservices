package com.daimler.parking.reservation.response;

public class ParkingExtensionResponse extends BaseResponse {

	private String bookingId;
	private String startTime;
	private int endTime;
	private double priceFirstHour;
	private double priceTotal;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public int getEndTime() {
		return endTime;
	}

	public void setEndTime(int endTime) {
		this.endTime = endTime;
	}

	public double getPriceFirstHour() {
		return priceFirstHour;
	}

	public void setPriceFirstHour(double priceFirstHour) {
		this.priceFirstHour = priceFirstHour;
	}

	public double getPriceTotal() {
		return priceTotal;
	}

	public void setPriceTotal(double priceTotal) {
		this.priceTotal = priceTotal;
	}

}
