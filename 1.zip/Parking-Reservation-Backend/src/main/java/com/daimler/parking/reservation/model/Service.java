package com.daimler.parking.reservation.model;

import java.io.Serializable;

public class Service implements Serializable {
	
	

}
