package com.daimler.parking.reservation.handler;

import java.io.IOException;
import java.net.URI;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.daimler.parking.reservation.model.VehicleDetails;
import com.daimler.parking.reservation.properties.CPDServiceProperties;
import com.microsoft.applicationinsights.TelemetryClient;
import com.microsoft.applicationinsights.telemetry.Duration;

@Component
public class CpdHandler {

	private static final Logger logger = LoggerFactory.getLogger(CpdHandler.class);

	CPDServiceProperties properties;
	RestTemplate restTemplate;
	StopWatch stopWatch = new StopWatch();
	private Duration responseTime;
	
	private ResourceLoader resourceLoader;
	
//	@PostConstruct
//    public void init() {
//        System.setProperty("proxyHost", "53.88.72.33");
//        System.setProperty("proxyPort", "3128");
//    }

	@Autowired
	public CpdHandler(CPDServiceProperties properties, RestTemplate restTemplate, ResourceLoader resourceLoader) {
		this.properties = properties;
		this.restTemplate = restTemplate;
		this.resourceLoader = resourceLoader;
	}

	public ResponseEntity<VehicleDetails> getVehicleInfoWithFinOrVin(String finOrVin) throws RestClientException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
		
		logger.info("Inside getVehicleInfoWithFinOrVin method");
		
		String cpdURL = new StringBuilder(properties.getUserUrl()).append(finOrVin).toString();
		
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(cpdURL);

		URI uri = builder.build().encode().toUri();
		
		stopWatch.reset();
		
        stopWatch.start();
		ResponseEntity<VehicleDetails> vehicleInfo = createRestTemplate().exchange(uri, HttpMethod.GET, getCPDHeaders(), VehicleDetails.class);
		stopWatch.stop();
		
		responseTime = new Duration(stopWatch.getTime());
        TelemetryClient telemetry = new TelemetryClient();
        telemetry.trackDependency("CPD Service", "Get Vehicle Info Service with FinOrVin ",responseTime, true);
        
		return vehicleInfo;
	}

	private HttpEntity<String> getCPDHeaders() {
		final HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + properties.getBasicAuth().getBase64BasicAuthString());
		headers.add("X-ApplicationName", properties.getAppName());
		headers.add("X-TrackingId", UUID.randomUUID().toString());
		HttpEntity<String> reqHeaders=new HttpEntity<>(headers);
		logger.info("X-TrackingId:::"+UUID.randomUUID().toString());
		return reqHeaders;
	}

	private RestTemplate createRestTemplate() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {
		 char[] password = properties.getCertPassword().toCharArray();
		 
	       	/*	       
	       
	        * Create an SSLContext that uses  the client certificate
	        * and the client-truststore.jks as the trust material (trusted CA certificates)
	        */
			
		SSLContext sslContext = new SSLContextBuilder().loadKeyMaterial(loadPfx(properties.getPfxPath(), password), password)
	              .loadTrustMaterial(loadKeyStore(properties.getTrustStorePath(),password), new TrustStrategy() {

	                  public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
	                     
	                	  return true;
	                  }})
	               .build();
	    
	       SSLConnectionSocketFactory sslSocketFactory = null;

	       sslSocketFactory = new SSLConnectionSocketFactory( sslContext );
	       
	       HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslSocketFactory).build();
	       HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
	       requestFactory.setHttpClient(httpClient);
	       return new RestTemplate(requestFactory);
	}

	private KeyStore loadKeyStore(String file, char[] password) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException { 
        final KeyStore keystore = KeyStore.getInstance("JKS"); 
        Resource resource=resourceLoader.getResource(file);
       
        try { 
       
            keystore.load(resource.getInputStream(), password); 
        } finally { 
           // IOUtils.closeQuietly(is); 
        } 
        return keystore; 
    }

	private KeyStore loadPfx(String file, char[] password) throws KeyStoreException {  
	KeyStore keyStore = KeyStore.getInstance("PKCS12");
    // File key = ResourceUtils.getFile(file);
    Resource resource=resourceLoader.getResource(file);
   try{
    keyStore.load(resource.getInputStream(), password);
   }catch (Exception e) {
		
	}
    return keyStore;
    }

}
