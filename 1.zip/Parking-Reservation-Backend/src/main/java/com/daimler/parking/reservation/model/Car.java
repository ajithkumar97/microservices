package com.daimler.parking.reservation.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Car implements Serializable {

	@JsonProperty("FinOrVin")	
	private String finOrVin;
	
	@JsonProperty("Services")	
	private List<Service> services = new ArrayList<Service>();

	public String getFinOrVin() {
		return finOrVin;
	}

	public void setFinOrVin(String finOrVin) {
		this.finOrVin = finOrVin;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

}
