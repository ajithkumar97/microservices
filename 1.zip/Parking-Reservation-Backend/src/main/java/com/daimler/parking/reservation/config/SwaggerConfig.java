package com.daimler.parking.reservation.config;

import static com.google.common.collect.Lists.newArrayList;
import static springfox.documentation.schema.AlternateTypeRules.newRule;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.async.DeferredResult;

import com.fasterxml.classmate.TypeResolver;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.ApiKeyVehicle;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Swagger Configuration: force use of overridden properties from swagger.properties in src/main/resources
 * and provides default behaviour where to scan for rest api resources.
 */
@PropertySource("classpath:swagger/swagger.properties")
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    //Base Package where to start to scan for Rest API
    private static final String REST_PACKAGE_PATH = "com.daimler.parking.reservation.controller";

    @Autowired
    private TypeResolver typeResolver;

    /**
     * Provides basic configuration for Swagger.
     * See at http://springfox.github.io/springfox/docs/current/ for more configuration options.
     *
     * @return A new Docket with configuration for this project.
     */
    @Bean
    public Docket parkingReservationServiceApi() {
        return new Docket(DocumentationType.SWAGGER_2).select()
                .apis(RequestHandlerSelectors.basePackage(REST_PACKAGE_PATH))
                .paths(PathSelectors.regex("/.*"))
                .build().pathMapping("/")
                .directModelSubstitute(LocalDate.class, String.class)
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(newRule(typeResolver.resolve(DeferredResult.class, typeResolver.resolve(ResponseEntity.class, WildcardType.class)), typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(true)
                .globalResponseMessage(RequestMethod.GET,
                    newArrayList(new ResponseMessageBuilder()
                        .code(500)
                        .message("500 message")
                        .responseModel(new ModelRef("Error"))
                        .build()))
                .apiInfo(getApiInfo())
                .securitySchemes(newArrayList(apiKey()))
                /*.securityContexts(newArrayList(securityContext()))*/
                .protocols(protocols())
                .securitySchemes(securitySchemes())
                .securityContexts(securityContexts());
    }
    
    private ApiKey apiKey() {
        return new ApiKey("api_key", "api_key", "header");
    }
    
/*    private SecurityContext securityContext() {
        return SecurityContext.builder().securityReferences(defaultAuth())
                .forPaths(PathSelectors.regex("/c2creservation.*")).build();
    }*/

    List<SecurityReference> defaultAuth() {
       /* AuthorizationScope authorizationScope = new AuthorizationScope(
                "global", "accessEverything");*/
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[0];
//        authorizationScopes[0] = authorizationScope;
        return newArrayList(new SecurityReference("api_key", authorizationScopes));
    }


    private List<SecurityContext> securityContexts() {
        List<SecurityContext> securityContexts   = Arrays.asList(SecurityContext.builder().forPaths(PathSelectors.regex("/.*")).securityReferences(securityReferences()).build());
        return securityContexts;
    }

    private List<? extends SecurityScheme> securitySchemes() {
         List<SecurityScheme> authorizationTypes = Arrays.asList(new ApiKey("api_key", "api_key", "header"));
          return authorizationTypes;
    }

    private Set<String> protocols() {
        Set<String> protocols = new HashSet<>();
        protocols.add("http");
        protocols.add("https");
        return protocols;
    }
    
    private List<SecurityReference> securityReferences() {
        List<SecurityReference> securityReferences = Arrays.asList(SecurityReference.builder().reference("api_key").scopes(new AuthorizationScope[0]).build());
        return securityReferences;
    }
    
      @Bean
      SecurityConfiguration security() {
        return new SecurityConfiguration(
            null,
            null,
            null,
            null,
            null,
            ApiKeyVehicle.HEADER, 
            "api_key", 
            "," /*scope separator*/);
      }

    private ApiInfo getApiInfo() {
        return new ApiInfoBuilder()
                .title("C2C-Reservation API")
                .description(getApiDescription("<Missing API description>"))
                .license(null)
                .version("1.0")
                .build();
    }

    private String getApiDescription(String defaultText) {
        InputStream is = ClassLoader.getSystemResourceAsStream("swagger/swagger-api-description.txt");
        if (null != is) {
            try (java.util.Scanner s = new java.util.Scanner(is)) {
                if (s.useDelimiter("\\A").hasNext()) {
                    return s.next();
                }
            }
        }
        return defaultText;
    }
}
