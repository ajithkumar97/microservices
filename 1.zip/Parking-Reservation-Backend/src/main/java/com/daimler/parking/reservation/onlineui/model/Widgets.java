package com.daimler.parking.reservation.onlineui.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Widgets
{
	@JsonProperty("Name")
	private String name;
	
	@JsonProperty("Version")
	private String version;

	@JsonProperty("WidgetData")
	private String widgetData;
	
	@JsonProperty("Events")
	private List<Events> events;

	@JsonProperty("UID")
	private String uid;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public List<Events> getEvents() {
		return events;
	}

	public void setEvents(List<Events> events) {
		this.events = events;
	}

	public String getWidgetData() {
		return widgetData;
	}

	public void setWidgetData(String widgetData) {
		this.widgetData = widgetData;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "Widgets [name=" + name + ", uid=" + uid + ", events=" + events + ", widgetData=" + widgetData
				+ ", version=" + version + "]";
	}

}
