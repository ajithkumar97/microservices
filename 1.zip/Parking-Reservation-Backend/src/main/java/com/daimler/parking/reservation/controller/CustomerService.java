package com.daimler.parking.reservation.controller;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.request.CancellationRequest;
import com.daimler.parking.reservation.request.ParkingBarrierRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
@Api(value = "Search Parking Spaces ", description = "Endpoint for CAC")
@RequestMapping(value = "/c2creservation/v1/cac")
public class CustomerService extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

	@Autowired
	private C2CManager c2cmanager;


	/**
	 * Open a Parking Barrier on for a given unique barrier identifier(barrierUuid)
	 * 
	 * @param barrierUuid: <string>, # unique parking barrier identifier
	 * @return Open Parking Barrier response.
	 * 
	 **/
	@ApiOperation(value = "Open the Parking Barrier for a customer")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Parking Barrier is opened successfully"),
			@ApiResponse(code = 204, message = "Reason to open barrier is missing"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing"), @ApiResponse(code = 403, message = "User is not authorized"),
			@ApiResponse(code = 500, message = "A provider or general error occurred") })


	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})


	@RequestMapping(value = "/openbarrier", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_SUPPORT_MANAGER')")
	public BaseResponse openParkingBarrier(
			@ApiParam(value = "Parking Barrier Request", required = true) @Valid @RequestBody ParkingBarrierRequest parkingBarrierRequest, @RequestHeader(value = "Authorization", required = false) String authorization)
					throws JsonProcessingException {

		logger.info( "Invoking service  openParkingBarrier with Barrierid =" + parkingBarrierRequest.getBarrierId() +", bookingId = " + parkingBarrierRequest.getBookingId() );
		BaseResponse parkingBarrierResponse = new BaseResponse();
		/*	
    	if(null == parkingBarrierRequest.getBookingId() || parkingBarrierRequest.getBookingId().isEmpty() )
    	{
    		logger.info( "Booking id is null" );
    		parkingBarrierResponse.setStatusCode("204");
            parkingBarrierResponse.setStatusMessage("Booking Id is required");
    	}
    	else if(null == parkingBarrierRequest.getBarrierId() || parkingBarrierRequest.getBarrierId().isEmpty())
        {
        	logger.info( "Barrier id is null" );
        	parkingBarrierResponse.setStatusCode("204");
        	parkingBarrierResponse.setStatusMessage("Barrier Id is required");
        }*/
		if(null == parkingBarrierRequest.getBarrierReason() || parkingBarrierRequest.getBarrierReason().isEmpty())
		{
			logger.info( "Barrier reason is required" );
			parkingBarrierResponse.setStatusCode("204");
			parkingBarrierResponse.setStatusMessage("Reason to open barrier is missing");	
		}
		else
		{
			//			Call Ampido here to open barrier   		
			parkingBarrierResponse.setStatusCode("200");
			parkingBarrierResponse.setStatusMessage("Barrier is opened successfully");
		}
		return parkingBarrierResponse;
	}


	/**
	 * Cancel a Parking Space on for a given unique rent identifier(bookingId)
	 * 
	 * @param bookingId:
	 *            <string>, # unique rent identifier
	 * @return Cancellation response.
	 */

	@ApiOperation(value = "Cancel booked reservation")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Cancellation done successfully"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing"),
			@ApiResponse(code = 403, message = "User is not authorized"),
			@ApiResponse(code = 500, message = "A provider or general error occurred") })


	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})

	@RequestMapping(value ="/cancel", method = RequestMethod.DELETE, consumes =
	MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('SUPPORT_USER','SUPPORT_MANAGER')") 
	public ResponseEntity<BaseResponse> cancelBooking(
			@Valid @RequestBody CancellationRequest cancellationRequest,
			@RequestHeader(value = "Authorization", required = false, defaultValue = "Basic c3VwcG9ydE1hbmFnZXI6c3VwcG9ydE1hbmFnZXJAMTIz") String authorization) throws
	JsonProcessingException {

		logger.info("Invoking Cancel reservation with request"+cancellationRequest.toString());

		BaseResponse cancleResponse = c2cmanager.getAmpidoAdapter().cancelReservedParkingSpace(cancellationRequest);
		logger.info("cancellation request was handled successful");
		if(cancleResponse.getStatusCode()=="422")
			return new ResponseEntity<BaseResponse>(cancleResponse, HttpStatus.UNPROCESSABLE_ENTITY);
		else
			return new ResponseEntity<BaseResponse>(cancleResponse, HttpStatus.OK);
	}



	@SuppressWarnings("unchecked")
	@ApiOperation(value = "Returns all parking Spaces details for the given bounding box(TopLeft-BottonRight) and start time.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.")
	})


	@ApiImplicitParams({
		@ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})


	@RequestMapping(value = "/parkinglist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_SUPPORT_USER')")
	public  ParkingSpaceListResponse getParkingSpaceList(
			//			ParkingSpaceListResponse
			@ApiParam(value = "LatitudeTopLeft, range: -90.0 - 90.0", defaultValue = "48.138547", required = true)
			@RequestParam(value = "latitudeTopLeft", required = true)
			@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
			@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
			double latitudeTopLeft,

			@ApiParam(value = "LongitudeTopLeft, range: -180.0 - 180.0", defaultValue = "11.572228", required = true)
			@RequestParam(value = "longitudeTopLeft", required = true)
			@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
			@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
			double longitudeTopLeft,

			@ApiParam(value = "LatitudeBottomRight, range: -90.0 - 90.0", defaultValue = "48.132827", required = true)
			@RequestParam(value = "latitudeBottomRight", required = true)
			@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
			@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
			double latitudeBottomRight,

			@ApiParam(value = "LongitudeBottomRight, range: -180.0 - 180.0", defaultValue = "11.5859380", required = true)
			@RequestParam(value = "longitudeBottomRight", required = true)
			@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
			@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
			double longitudeBottomRight,

			@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-07-26T11:05:55.312Z", required = true, type="ISO 8601 Date")
			@RequestParam(value = "startTime", required = true)
			String startTime,

			@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-07-26T12:05:55.312Z", required = false, type="ISO 8601 Date")
			@RequestParam(value = "endTime", required = false)
			String endTime, @RequestHeader(value = "Authorization", required = false) String authorization
			)throws DateTimeParseException, JsonParseException, JsonMappingException, IOException {

		ZonedDateTime now = ZonedDateTime.now();

		logger.info("Invoking service  getParkingSpaceList for Customer Service at Time "+now);

		ParkingSpaceListResponse parkingSpaceListResponse  = new ParkingSpaceListResponse() ;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
		BaseResponse baseResponse = null;
		try{   	
			if(null!=startTime )
			{
				//just to check if time is in zulu, but not using variable
				LocalDateTime startTimeCheck = LocalDateTime.parse(startTime,dateTimeFormatter);       	
			}
			if(null!=endTime)
			{
				//just to check if time is in zulu, but not using variable
				LocalDateTime endTimeCheck = LocalDateTime.parse(endTime,dateTimeFormatter);
			}
			
			
			
			StringBuffer parkingSpaceRequestSB = new StringBuffer();
			
			parkingSpaceRequestSB.append("LatitudeTopLeft : "+latitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("LongitudeTopLeft : "+longitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("LatitudeBottomRight : "+latitudeBottomRight ).append(" ,");
			parkingSpaceRequestSB.append("LongitudeBottomRight : "+latitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("Start Time  : "+startTime ).append(" ,");
			parkingSpaceRequestSB.append("End Time : "+endTime ).append(" ,");
			
			logger.info("Request Parameters ==>"+parkingSpaceRequestSB.toString());
			
			parkingSpaceListResponse = new ParkingSpaceListResponse();
			parkingSpaceListResponse = c2cmanager.getAmpidoAdapter().getParkingListFromAmpido(latitudeTopLeft,longitudeTopLeft,
					latitudeBottomRight, longitudeBottomRight,startTime, endTime); 

			if(null != parkingSpaceListResponse) {
				ObjectMapper mapper = new ObjectMapper();
				logger.info("Response ==" +mapper.writeValueAsString(parkingSpaceListResponse));
			}


			now = ZonedDateTime.now();
			logger.info("Invoking service  getParkingSpaceList for Customer Service at Time "+now);

			return parkingSpaceListResponse;
		}
		catch(DateTimeException dateTimeException)
		{
			logger.warn("DateTimeException occured");
			throw dateTimeException;

		}
		catch(Exception e){
			logger.info("General error occured"+ e.getMessage());
			e.printStackTrace();
			throw e;
		}		

	} 	

}
