package com.daimler.parking.reservation.services;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.model.SessionContextDetail;
import com.daimler.parking.reservation.properties.C2cExternalProperties;
import com.microsoft.applicationinsights.TelemetryClient;
import com.microsoft.applicationinsights.telemetry.Duration;

@Component
public class SessionContextService {

	@Autowired
	C2cExternalProperties c2cExternalProperties;
	
	@Autowired
	RestTemplate restTemplate;
	
	private StopWatch stopWatch = new StopWatch();
	private Duration responseTime;
	private static final Logger logger = LoggerFactory.getLogger(SessionContextService.class);
	
	public boolean isValidSessionId(String sessionId)
	{
		logger.info("Validating Session Id " + sessionId + " for NTG6 request");
		String sessionUrl = c2cExternalProperties.getNtg6validateSessionIdUrl().replace("{sessionID}", sessionId);
		
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Content-Type", "application/json;charset=UTF-8");
		headers.set("Ocp-Apim-Subscription-Key", "7fcb1d3b3d2b49e2a9b81b4af95ce9ba");
		
		HttpEntity entity = new HttpEntity(headers);
		
		stopWatch.reset();
		stopWatch.start();
		ResponseEntity<String> response  = restTemplate.exchange(sessionUrl, HttpMethod.GET, entity, String.class);
		stopWatch.stop();
		
		logger.info("Response of session validation is "+response.getBody().toString()+
				"Response code is"+response.getStatusCodeValue());
		
		responseTime = new Duration(stopWatch.getTime());
		TelemetryClient telemetry = new TelemetryClient();
		telemetry.trackDependency("Daimler AG API", "Session Validation of session id "+sessionId,responseTime, true);

		if(response.getBody().equals("true"))
		{
			return true;
		}	
		else
		return false;
		
	}
	
	
	public SessionContextDetail getSessionContextDetails(String sessionId)
	{
		logger.info("Fetching Session  Context details with session for NTG6 request");
		String sessionContextUrl = c2cExternalProperties.getSessionContextDetailsUrl().replace("{sessionID}", sessionId);
		
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Content-Type", "application/json;charset=UTF-8");
		headers.set("Ocp-Apim-Subscription-Key", c2cExternalProperties.getOcp_Apim_Subscription_Key());
		
		HttpEntity entity = new HttpEntity(headers);
		
		SessionContextDetail sessionContextDetail = new SessionContextDetail();
		
		stopWatch.reset();
		
		stopWatch.start();
		
		ResponseEntity<SessionContextDetail> response  = restTemplate.exchange(sessionContextUrl, HttpMethod.GET, entity, SessionContextDetail.class);
		
		sessionContextDetail = response.getBody();
		
		stopWatch.stop();
		
		logger.info("Response of session Context Details is "+response.getBody().toString()+
				"Response code is"+response.getStatusCodeValue());
		
		responseTime = new Duration(stopWatch.getTime());
		TelemetryClient telemetry = new TelemetryClient();
		telemetry.trackDependency("Daimler AG API", "Session Context Details of session id "+sessionId,responseTime, true);

		logger.info("sessionContextDetail==="+sessionContextDetail.toString());
		
		logger.info("Exiting Service  Session Context details");
		
	  return sessionContextDetail;
		
	}
	
	
	
}
