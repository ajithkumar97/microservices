package com.daimler.parking.reservation.exceptions.handler.data;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/*
 * When adding new error codes, please also update resources/swagger/swagger-api-description.txt
 */
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum ErrorCode {
	@JsonProperty("generalFailure")
    GENERAL_FAILURE(7001),
    @JsonProperty("invalidParameter")
    INVALID_PARAMETER(7003),
    @JsonProperty("missingParameter")
    MISSING_PARAMETER(7004),
    @JsonProperty("providerError")
    PROVIDER_ERROR(7007),
    @JsonProperty("authorizationError")
    AUTHORIZATION_ERROR(7008),
    @JsonProperty("areaTooLarge")
    AREA_TOO_LARGE(7009),
    @JsonProperty("missingPayload")
    MISSING_PAYLOAD(7010);

    private final int value;

    ErrorCode(int value) {
        this.value = value;
    }


    @JsonValue
    public int getValue() {
        return value;
    }
}
