package com.daimler.parking.reservation.controller;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daimler.parking.reservation.exceptions.AuthorizationException;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.SessionContextDetail;
import com.daimler.parking.reservation.model.VehicleDetails;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;
import com.daimler.parking.reservation.services.SessionContextService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@Validated
@Api(value = "Search Parking Spaces ", description = "Endpoint for Retrieving C2C Parking Space.")
@RequestMapping(value = "/c2creservation/v1")
public class Accumulator extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(Accumulator.class);

	@Autowired
	private C2CManager c2cmanager;

	@Autowired
	SessionContextService sessionContextService;
	
	/**
	 * Returns all parking Space details on the given latitude, longitude,radius
	 * and start time.
	 *
	 * @param latitude:
	 *            <DECIMAL> # search location
	 * @param longitude:
	 *            <DECIMAL> # search location
	 * @param distance:
	 *            <DECIMAL> # search radius in km. Max: 20km
	 * @param page[number]:
	 *            <INTEGER> # page number of search result
	 * @param page[size]:
	 *            <INTEGER> # number of results per page
	 * @param start_time:
	 *            <ISO 8601> # start time of parking lot booking
	 * @param end_time:
	 *            <ISO 8601> # (optional) end time of parking lot booking
	 * @param max_results:
	 *            <Decimal(3)> # (optional) maximum number of parking lots in
	 *            result, sorted by distance
	 * 
	 * @return dummy static ViewParkingSpaceResponses as List
	 * @throws IOException
	 * 
	 **/

	@CrossOrigin
	@ApiOperation(value = "Returns all parking Spaces details for the given bounding box(TopLeft-BottonRight) and start time.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	
	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header"),
        @ApiImplicitParam(name = "X-SessionId", value = "Session Id for the CAR NTG6", required = true, dataType = "string", paramType = "header",defaultValue = "673c7475-b368-451e-90a0-4da44bcd5f9a")
	})
	
	@RequestMapping(value = "/accumulator/parkinglist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_NTG_USER','ROLE_NTG_MANGER')")
	public ParkingSpaceListResponse getParkingSpaceList(
			// ParkingSpaceListResponse
			@ApiParam(value = "LatitudeTopLeft, range: -90.0 - 90.0", defaultValue = "48.138547", required = true) @RequestParam(value = "latitudeTopLeft", required = true) @DecimalMin(value = "-90.0", message = "latitude must be at least -90.0") @DecimalMax(value = "90.0", message = "latitude can only be up to 90.0") double latitudeTopLeft,

			@ApiParam(value = "LongitudeTopLeft, range: -180.0 - 180.0", defaultValue = "11.572228", required = true) @RequestParam(value = "longitudeTopLeft", required = true) @DecimalMin(value = "-180.0", message = "longitude must be at least -180.0") @DecimalMax(value = "180.0", message = "longitude can only be up to 180.0") double longitudeTopLeft,

			@ApiParam(value = "LatitudeBottomRight, range: -90.0 - 90.0", defaultValue = "48.132827", required = true) @RequestParam(value = "latitudeBottomRight", required = true) @DecimalMin(value = "-90.0", message = "latitude must be at least -90.0") @DecimalMax(value = "90.0", message = "latitude can only be up to 90.0") double latitudeBottomRight,

			@ApiParam(value = "LongitudeBottomRight, range: -180.0 - 180.0", defaultValue = "11.5859380", required = true) @RequestParam(value = "longitudeBottomRight", required = true) @DecimalMin(value = "-180.0", message = "longitude must be at least -180.0") @DecimalMax(value = "180.0", message = "longitude can only be up to 180.0") double longitudeBottomRight,

			@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-07-26T11:05:55.312Z", required = true, type = "ISO 8601 Date") @RequestParam(value = "startTime", required = true) String startTime,

			@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-07-26T12:05:55.312Z", required = false, type = "ISO 8601 Date") @RequestParam(value = "endTime", required = false) String endTime
			, @RequestHeader(value = "Authorization", required = false, defaultValue = "Basic bnRnVXNlcjpudGdVc2VyQCEyMw==") String authorization ,	@ApiIgnore HttpServletRequest request)
			throws DateTimeParseException, JsonParseException, JsonMappingException, IOException {
		
		ZonedDateTime now = ZonedDateTime.now();
		
		logger.info("Invoking service  getParkingSpaceList for Accumulator at Time "+now);
		
		StringBuffer parkingSpaceRequestSB = new StringBuffer();
		
		parkingSpaceRequestSB.append("LatitudeTopLeft : "+latitudeTopLeft ).append(" ,");
		parkingSpaceRequestSB.append("LongitudeTopLeft : "+longitudeTopLeft ).append(" ,");
		parkingSpaceRequestSB.append("LatitudeBottomRight : "+latitudeBottomRight ).append(" ,");
		parkingSpaceRequestSB.append("LongitudeBottomRight : "+latitudeTopLeft ).append(" ,");
		parkingSpaceRequestSB.append("Start Time  : "+startTime ).append(" ,");
		parkingSpaceRequestSB.append("End Time : "+endTime ).append(" ,");
		parkingSpaceRequestSB.append("SessionId  : "+request.getHeader("X-SessionId"));
		
		logger.info("Request Parameters ==>"+parkingSpaceRequestSB.toString());
		
		ParkingSpaceListResponse parkingSpaceListResponse = new ParkingSpaceListResponse();
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
		try {
			if (null != startTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime startTimeCheck = LocalDateTime.parse(startTime, dateTimeFormatter);
			}
			if (null != endTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime endTimeCheck = LocalDateTime.parse(endTime, dateTimeFormatter);
			}
			parkingSpaceListResponse = new ParkingSpaceListResponse();
			
			if(sessionContextService.isValidSessionId(request.getHeader("X-SessionId"))==false)
			{
				logger.info("Invalid Session Id");	
				throw new AuthorizationException("Invalid SessionId");
			}
			
			
			
			
			parkingSpaceListResponse = c2cmanager.getAmpidoAdapter().getParkingListFromAmpido(latitudeTopLeft,
					longitudeTopLeft, latitudeBottomRight, longitudeBottomRight, startTime, endTime);

			if(null != parkingSpaceListResponse) {
			ObjectMapper mapper = new ObjectMapper();
			logger.info("Parking Space Search Response ==" +mapper.writeValueAsString(parkingSpaceListResponse));
			}
			
			now = ZonedDateTime.now();
			
			logger.info("Exiting  service  getParkingSpaceList for Accumulator at Time "+now);
			
			return parkingSpaceListResponse;
		} catch (DateTimeException dateTimeException) {
			logger.warn("DateTimeException occured");
			throw dateTimeException;

		} catch (Exception e) {
			logger.warn("general error occured" + e.getMessage());
			e.printStackTrace();
			throw e;
		}
	}
	
	
	

}
