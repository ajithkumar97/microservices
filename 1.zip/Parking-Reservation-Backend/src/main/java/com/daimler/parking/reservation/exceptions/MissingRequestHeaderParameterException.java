package com.daimler.parking.reservation.exceptions;

public class MissingRequestHeaderParameterException extends RuntimeException {
    public MissingRequestHeaderParameterException(String format, Object ... args) {
        super(String.format(format, args));
    }
    public MissingRequestHeaderParameterException(){
    	super();
    }

}
