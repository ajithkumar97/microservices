package com.daimler.parking.reservation.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daimler.parking.reservation.handler.CpdHandler;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.ParkingSpaceResponse;
import com.daimler.parking.reservation.model.SessionContextDetail;
import com.daimler.parking.reservation.model.VehicleDetails;
import com.daimler.parking.reservation.request.ParkingBarrierRequest;
import com.daimler.parking.reservation.request.RentRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;
import com.daimler.parking.reservation.services.SessionContextService;
import com.daimler.parking.reservation.utils.EncryptionUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiKeyAuthDefinition;
import io.swagger.annotations.ApiKeyAuthDefinition.ApiKeyLocation;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SecurityDefinition;
import io.swagger.annotations.SwaggerDefinition;

@RestController
@Validated
@Api(value = "Search Parking Spaces", description = "Endpint for C2C Parking Reservation")
@SwaggerDefinition(securityDefinition = @SecurityDefinition(apiKeyAuthDefinitions = {
		@ApiKeyAuthDefinition(key = "", name = "Authorization", in = ApiKeyLocation.HEADER, description = "X-API-Key") }))
@RequestMapping(value = "/c2creservation/v1")
public class C2CReservation extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(C2CReservation.class);

	@Autowired
	private C2CManager c2cmanager;
	
	@Autowired
	CpdHandler cpdHandler;

	@Autowired
	SessionContextService sessionContextService;
	
	/**
	 * Returns all parking Space details on the given latitude, longitude,radius
	 * and start time.
	 *
	 * @param latitude:
	 *            <DECIMAL> # search location
	 * @param longitude:
	 *            <DECIMAL> # search location
	 * @param distance:
	 *            <DECIMAL> # search radius in km. Max: 20km
	 * @param page[number]:
	 *            <INTEGER> # page number of search result
	 * @param page[size]:
	 *            <INTEGER> # number of results per page
	 * @param start_time:
	 *            <ISO 8601> # start time of parking lot booking
	 * @param end_time:
	 *            <ISO 8601> # (optional) end time of parking lot booking
	 * @param max_results:
	 *            <Decimal(3)> # (optional) maximum number of parking lots in
	 *            result, sorted by distance
	 * 
	 * @return dummy static ViewParkingSpaceResponses as List
	 * @throws IOException
	 * 
	 **/

	@SuppressWarnings("unchecked")
	@CrossOrigin
	@ApiOperation(value = "Returns all parking Spaces details for the given bounding box(TopLeft-BottonRight) and start time.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})
	
	@RequestMapping(value = "/parkinglist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_MMA_USER','ROLE_MMA_MANAGER')")
	public ParkingSpaceListResponse getParkingSpaceList(
			// ParkingSpaceListResponse
			@ApiParam(value = "LatitudeTopLeft, range: -90.0 - 90.0", defaultValue = "48.138547", required = true) @RequestParam(value = "latitudeTopLeft", required = true) @DecimalMin(value = "-90.0", message = "latitude must be at least -90.0") @DecimalMax(value = "90.0", message = "latitude can only be up to 90.0") double latitudeTopLeft,

			@ApiParam(value = "LongitudeTopLeft, range: -180.0 - 180.0", defaultValue = "11.572228", required = true) @RequestParam(value = "longitudeTopLeft", required = true) @DecimalMin(value = "-180.0", message = "longitude must be at least -180.0") @DecimalMax(value = "180.0", message = "longitude can only be up to 180.0") double longitudeTopLeft,

			@ApiParam(value = "LatitudeBottomRight, range: -90.0 - 90.0", defaultValue = "48.132827", required = true) @RequestParam(value = "latitudeBottomRight", required = true) @DecimalMin(value = "-90.0", message = "latitude must be at least -90.0") @DecimalMax(value = "90.0", message = "latitude can only be up to 90.0") double latitudeBottomRight,

			@ApiParam(value = "LongitudeBottomRight, range: -180.0 - 180.0", defaultValue = "11.5859380", required = true) @RequestParam(value = "longitudeBottomRight", required = true) @DecimalMin(value = "-180.0", message = "longitude must be at least -180.0") @DecimalMax(value = "180.0", message = "longitude can only be up to 180.0") double longitudeBottomRight,

			@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-07-26T11:05:55.312Z", required = true, type = "ISO 8601 Date") @RequestParam(value = "startTime", required = true) String startTime,

			@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-07-26T12:05:55.312Z", required = false, type = "ISO 8601 Date") @RequestParam(value = "endTime", required = false) String endTime,
			@RequestHeader(value = "Authorization", required = false , defaultValue ="Basic bW1hVXNlcjptbWFVc2VyQCEyMw==") String authorization)
			throws DateTimeParseException, JsonParseException, JsonMappingException, IOException {
		
		ZonedDateTime now = ZonedDateTime.now();
		
		logger.info("Invoking service  getParkingSpaceList for C2C Reservation "+now);

		ParkingSpaceListResponse parkingSpaceListResponse = new ParkingSpaceListResponse();
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
		BaseResponse baseResponse = null;
		
		try {
			if (null != startTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime startTimeCheck = LocalDateTime.parse(startTime, dateTimeFormatter);
			}
			if (null != endTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime endTimeCheck = LocalDateTime.parse(endTime, dateTimeFormatter);
			}
			
			
			StringBuffer parkingSpaceRequestSB = new StringBuffer();
			
			parkingSpaceRequestSB.append("LatitudeTopLeft : "+latitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("LongitudeTopLeft : "+longitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("LatitudeBottomRight : "+latitudeBottomRight ).append(" ,");
			parkingSpaceRequestSB.append("LongitudeBottomRight : "+latitudeTopLeft ).append(" ,");
			parkingSpaceRequestSB.append("Start Time  : "+startTime ).append(" ,");
			parkingSpaceRequestSB.append("End Time : "+endTime ).append(" ,");
			
			logger.info("Request Parameters ==>"+parkingSpaceRequestSB.toString());
			
			parkingSpaceListResponse = c2cmanager.getAmpidoAdapter().getParkingListFromAmpido(latitudeTopLeft,
					longitudeTopLeft, latitudeBottomRight, longitudeBottomRight, startTime, endTime);

			now = ZonedDateTime.now();
			logger.info("Exiting  service  getParkingSpaceList for C2C Reservation "+now);
			
			return parkingSpaceListResponse;
		} catch (DateTimeException dateTimeException) {
			logger.warn("DateTimeException occured");
			throw dateTimeException;

		} catch (Exception e) {
			logger.warn("General error occured" + e.getMessage());
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * @param uuid
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws Exception 
	 */
	@CrossOrigin
	@ApiOperation(value = "Returns parking Spaces details for the given uuid")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	
	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})
	
	@RequestMapping(value = "/parkingspace/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_MMA_USER','ROLE_MMA_MANAGER')")
	public ParkingSpaceResponse getParkingSpace(

		@ApiParam(value = "slotID of parking lot ", defaultValue = "6Rp7GKjkA54Jz03L", required = true) @PathVariable(value = "id", required = true) String id,

		@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-07-26T11:05:55.312Z", required = false, type = "ISO 8601 Date")
		@RequestParam(value = "startTime", required = false)
		String startTime,

		@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-07-26T12:05:55.312Z", required = false, type = "ISO 8601 Date")
		@RequestParam(value = "endTime", required = false)
		String endTime ,  @RequestHeader(value = "Authorization", required = false,defaultValue ="Basic bW1hVXNlcjptbWFVc2VyQCEyMw==") String authorization
		) throws Exception {
		
		ZonedDateTime now = ZonedDateTime.now();
		
		logger.info("Invoking service  getParkingSpace Details  for C2C Reservation for the given SlotId " + "at Time " +now);
		
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
		try {
			if (null != startTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime startTimeCheck = LocalDateTime.parse(startTime, dateTimeFormatter);				
			}
			if (null != endTime) {
				// just to check if time is in zulu, but not using variable
				LocalDateTime endTimeCheck = LocalDateTime.parse(endTime, dateTimeFormatter);
			}
		
			StringBuffer requestParams = new StringBuffer();
			
			requestParams.append("Parking SlotID : "+id ).append(" ,");
			requestParams.append("Start Time  : "+startTime ).append(" ,");
			requestParams.append("End Time : "+endTime ).append(" ,");
			
			logger.info("Request Parameters ==>"+requestParams.toString());
			
			
		ParkingSpaceResponse parkingSpaceResponse = c2cmanager.getAmpidoAdapter().getParkingSpace(id,startTime, endTime );
		
		if(null != parkingSpaceResponse) {
		ObjectMapper mapper = new ObjectMapper();
		logger.info("Response ==" +mapper.writeValueAsString(parkingSpaceResponse));
		}else {
			logger.info("There is no Parking space details found for this Slot Id = "+id );
		}
		
		logger.info("Exiting  service  getParkingSpace Details  for C2C Reservation for the SlotId =="+id + "at Time " +now);
				
		return parkingSpaceResponse;
		} catch (DateTimeException dateTimeException) {
			logger.info("DateTimeException occured at getParkingSpace Details service");
			throw dateTimeException;

		} catch (Exception e) {
			logger.info("general error occured" + e.getMessage());
			throw e;
		}
		

	}

	/**
	 * Book Parking Space on for a given parking lot identifier
	 * 
	 * @param bookingRequest
	 * @param servletRequest
	 * @return
	 * @throws Exception 
	 */
	@ApiOperation(value = "Reserve a Parking Space for selected Parking lot")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Reservation is done successfully without errors."),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })


	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})
	
	
	@ApiImplicitParam(name = "CIAM_ID", value = "The distinguished ID of the authenticated user", defaultValue = "ciam-001", required = true, dataType = "string", paramType = "header")
	@RequestMapping(value = "/book", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_NTG_MANGER','ROLE_MMA_MANAGER')")
	public ResponseEntity<BaseResponse> bookParkingSpace(
			@ApiParam(value = "Booking Request for Parking Reservation", required = true) @Valid @RequestBody RentRequest rentRequest,
			HttpServletRequest servletRequest,@RequestHeader(value = "Authorization", required = false,defaultValue ="Basic bnRnbWFuYWdlcjpudGdtYW5hZ2VyQCEyMw==") String authorization)
			throws Exception {		
		
			logger.info("Invoking Service Book Parking Space");

			BaseResponse baseResponse = new BaseResponse();
			
			if (null != rentRequest) {
                ObjectMapper mapper = new ObjectMapper();
                logger.info("Booking Request parameter ==" + mapper.writeValueAsString(rentRequest));
                boolean b =c2cmanager.getCiamService().isAuthorized(servletRequest);
                if ( b) {
                	logger.info("User Has Valid Mercedes Pay Account");
                	baseResponse = c2cmanager.getAmpidoAdapter().bookParkingSpace(rentRequest);
                      baseResponse.setStatusCode("200");
                      baseResponse.setStatusMessage("Parking Reservation is done successfully ");
                }else{
                	logger.info("User Has InValid Mercedes Pay Account");
                	baseResponse.setStatusCode("401");
                	baseResponse.setStatusMessage("Invalid Mercedes Pay Account");
                }
           } else {
        	   baseResponse.setStatusCode("400");
                baseResponse.setStatusMessage("Invalid Request Rent Request ");
           }	
			
			logger.info("Exiting  Service Book Parking Space");
			return new ResponseEntity<BaseResponse>(baseResponse, HttpStatus.OK);
			
	}

	/**
	 * Open a Parking Barrier on for a given unique barrier
	 * identifier(barrierUuid)
	 * 
	 * @param barrierUuid:
	 *            <string>, # unique parking barrier identifier
	 * @return Open Parking Barrier response.
	 * 
	 **/
	@ApiOperation(value = "Open the Parking Barrier for a customer")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Parking Barrier is opened successfully"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing"),
			@ApiResponse(code = 403, message = "User is not authorized"),
			@ApiResponse(code = 500, message = "A provider or general error occurred") })
	

	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})
	
	
	@RequestMapping(value = "/openbarrier", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	@PreAuthorize("hasAnyRole('ROLE_NTG_MANGER','ROLE_MMA_MANAGER')")
	public BaseResponse openParkingBarrier(
			@ApiParam(value = "Parking Barrier Request", required = true) @Valid @RequestBody ParkingBarrierRequest parkingBarrierRequest, @RequestHeader(value = "Authorization", required = false) String authorization)
			throws JsonProcessingException {

		logger.info("Invoking service  openParkingBarrier with Barrierid =" + parkingBarrierRequest.getBarrierId()
				+ ", bookingId = " + parkingBarrierRequest.getBookingId());
		BaseResponse parkingBarrierResponse = new BaseResponse();

		/*
		 * if(null == parkingBarrierRequest.getBookingId() ||
		 * parkingBarrierRequest.getBookingId().isEmpty() ) { logger.info(
		 * "Booking id is null" ); parkingBarrierResponse.setStatusCode("404");
		 * parkingBarrierResponse.
		 * setStatusMessage("Reservation could not be found"); } else if(null ==
		 * parkingBarrierRequest.getBarrierId() ||
		 * parkingBarrierRequest.getBarrierId().isEmpty()) { logger.info(
		 * "Barrier id is null" ); parkingBarrierResponse.setStatusCode("404");
		 * parkingBarrierResponse.setStatusMessage("Barrier could not be found"
		 * ); }
		 */
		/*
		 * else if(null == parkingBarrierRequest.getBarrierReason() ||
		 * parkingBarrierRequest.getBarrierReason().isEmpty()) { logger.info(
		 * "Barrier reason is required" );
		 * parkingBarrierResponse.setStatusCode("422"); parkingBarrierResponse.
		 * setStatusMessage("Reason to open barrier is not given"); }
		 */

		// Call Ampido here to open barrier
		parkingBarrierResponse.setStatusCode("200");
		parkingBarrierResponse.setStatusMessage("Barrier is opened successfully");

		return parkingBarrierResponse;
	}

	/**
	 * @param ampidoURL
	 * @return
	 * @throws Exception 
	 * @throws URISyntaxException
	 */
	@RequestMapping(value = "/imageprovider", method = RequestMethod.GET, produces = "image/jpg")
	

	@ApiImplicitParams({
        @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
	})
	
	
	@ResponseStatus(HttpStatus.OK)
	public byte[] imageProvider(@RequestParam String ampidoURL) throws Exception {
		
		logger.info("Invoking service imageProvider for getting the image from Ampido");
		URL url = new URL(EncryptionUtils.decryptText(ampidoURL));
		
		URLConnection ucon = url.openConnection();

		InputStream is = ucon.getInputStream();
		BufferedInputStream bis = new BufferedInputStream(is);
		int current = 0;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		while ((current = bis.read()) != -1) {
			baos.write(current);
		}
		
		byte[] byt = baos.toByteArray();
		
		logger.info("Exiting  service imageProvider for getting the image from Ampido");
		
		return byt;
		
	}

	 

	/**
	 * Returns a parking Space details for the given parking lot.
	 * 
	 * @param parkingSlotId-unique
	 *            parking lot identifier
	 * @param start_time:
	 *            <ISO 8601> # start time of parking lot booking
	 * @param end_time:
	 *            <ISO 8601> # (optional) end time of parking lot booking
	 * 
	 * @return ViewParkingSpaceResponse
	 * 
	 * 
	 * 
	 * @ApiOperation(value = "Show the parking Space details for a given Parking
	 *                     Space")
	 * @ApiResponses(value = {
	 * @ApiResponse(code = 200, message = "Parking Space details fetched
	 *                   successfully without errors."),
	 * @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
	 * @ApiResponse(code = 403, message = "User is not authorized."),
	 * @ApiResponse(code = 500, message = "A provider or general error
	 *                   occurred.") })
	 * @RequestMapping(value ="/parkingSpace", method = RequestMethod.GET,
	 *                       produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * @ResponseStatus(HttpStatus.OK) public ParkingSlot viewParkingSpace(
	 * @ApiParam(value = "Start time of parking lot booking ", defaultValue =
	 *                 "2017-04-18T11:05:55.312Z", required = true)
	 * @RequestParam(value = "startTime", required = false)
	 * @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME) LocalDateTime
	 *                      startTime,
	 * 
	 * @ApiParam(value = "End time of parking lot booking ", defaultValue =
	 *                 "2017-04-18T12:05:55.312Z", required = false)
	 * @RequestParam(value = "endTime", required = false)
	 * @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime,
	 * 
	 * @ApiParam(value = "Viewing Request for Parking Reservation", required =
	 *                 true)
	 * @RequestParam(value = "parkingSlotId", required = true) String
	 *                     parkingSlotId) throws JsonProcessingException {
	 * 
	 *                     logger.info("Invoking service viewParkingSpace with
	 *                     ParkingSlotId ="+parkingSlotId);
	 * 
	 * 
	 * 
	 *                     return null;
	 * 
	 *                     }
	 * 
	 **/

	/**
	 * Upload parking offender Image
	 * 
	 * @param picture::
	 *            <Base64> # encoded picture
	 * @param slotUuid:
	 *            <string>, # unique parking lot identifier
	 * @param description:
	 *            <String> # description of the incidence
	 * @return 201 as status code, if its uploaded successfully.
	 **/

	/*
	 * @ApiOperation(value = "Upload the parking Offender Image")
	 * 
	 * @ApiResponses(value = {
	 * 
	 * @ApiResponse(code = 200, message =
	 * "Parking offender image is uploaded successfully"),
	 * 
	 * @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
	 * 
	 * @ApiResponse(code = 403, message = "User is not authorized."),
	 * 
	 * @ApiResponse(code = 500, message =
	 * "A provider or general error occurred.") })
	 * 
	 * @RequestMapping(value = "/parkingOffenderImage", method =
	 * RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * 
	 * @ResponseStatus(HttpStatus.OK) public ParkingOffenderResponse
	 * uploadParkingOffenderImage(
	 * 
	 * @ApiParam(value = "Uploading Parking Offender Image", required = true)
	 * 
	 * @Valid @RequestBody ParkingOffenderRequest parkingOffenderRequest) throws
	 * JsonProcessingException{
	 * 
	 * logger.info("Invoking service  uploadParkingOffenderImage");
	 * ParkingOffenderResponse offenderResponse = new ParkingOffenderResponse();
	 * 
	 * 
	 * offenderResponse.setMessage("Upload Success");
	 * offenderResponse.setStatusCode("200"); offenderResponse.
	 * setStatusMessage("Parking offender image is uploaded successfully");
	 * 
	 * return offenderResponse;
	 * 
	 * }
	 * 
	 */

	/**
	 * Extension request for a booked slot to check if parking extension is
	 * possible or not
	 * 
	 * @ @param bookingId: <string>, # unique rent identifier
	 * @ @param end_time: <ISO 8601> # (optional) end time of parking lot
	 *   booking
	 * @return Response code
	 * 
	 **/

	/*
	 * @ApiOperation(value =
	 * "Parking Space Extension request for a reserved parking  ")
	 * 
	 * @ApiResponses(value = {
	 * 
	 * @ApiResponse(code = 200, message =
	 * "Opening Barrier done successfully without errors."),
	 * 
	 * @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
	 * 
	 * @ApiResponse(code = 403, message = "User is not authorized."),
	 * 
	 * @ApiResponse(code = 500, message =
	 * "A provider or general error occurred.") })
	 * 
	 * @RequestMapping(value = "/parkingSpaceExtension", method =
	 * RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * 
	 * @ResponseStatus(HttpStatus.OK) public ParkingExtensionResponse
	 * getParkingSpaceExtension(
	 * 
	 * @ApiParam(value = "bookingId", required = true)
	 * 
	 * @RequestParam(value = "bookingId", required = true) String bookingId,
	 * 
	 * @ApiParam(value = "End time of parking lot booking ", defaultValue =
	 * "2017-04-18T12:05:55.312Z", required = false)
	 * 
	 * @RequestParam(value = "endTime", required = false)
	 * 
	 * @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime
	 * 
	 * ) throws JsonProcessingException {
	 * 
	 * 
	 * logger.info("Invoking service  getParkingSpaceExtension with bookingId ="
	 * +bookingId);
	 * 
	 * 
	 * 
	 * ParkingExtensionResponse ParkingExtensionResponse = new
	 * ParkingExtensionResponse();
	 * 
	 * ParkingExtensionResponse.setStatusCode("200");
	 * ParkingExtensionResponse.setStatusMessage("OK");
	 * 
	 * return ParkingExtensionResponse; }
	 * 
	 */

	/**
	 * Parking Extension Bookingr(bookingUUID)
	 * 
	 * @param bookingId:
	 *            <string>, # unique rent identifier
	 * @return Booking response.
	 * 
	 **/

	/*
	 * @ApiOperation(value = "Parking Extension Booking")
	 * 
	 * @ApiResponses(value = {
	 * 
	 * @ApiResponse(code = 200, message =
	 * "Parking Extension Booking successfully done"),
	 * 
	 * @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
	 * 
	 * @ApiResponse(code = 403, message = "User is not authorized."),
	 * 
	 * @ApiResponse(code = 500, message =
	 * "A provider or general error occurred.") })
	 * 
	 * @RequestMapping(value = "/extensionbooking", method = RequestMethod.POST,
	 * produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * 
	 * @ResponseStatus(HttpStatus.OK) public BookingDetails extensionbooking(
	 * 
	 * @ApiParam(value = "Parking Barrier Request for Reservation", required =
	 * true)
	 * 
	 * @Valid @RequestBody ParkingExtensionRequest parkingExtensionRequest )
	 * throws JsonProcessingException {
	 * 
	 * 
	 * logger.info("Invoking service  extensionBooking with Booking Id ="
	 * +parkingExtensionRequest.getBookingId());
	 * 
	 * BookingDetails bookingResponse = new BookingDetails();
	 * 
	 * return bookingResponse;
	 * 
	 * }
	 */
	
	@CrossOrigin
	@ApiOperation(value = "Returns the license plate details for the given vin or fin")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	 @ApiImplicitParams({
         @ApiImplicitParam(name = "X-TrackingId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
}) 
	@RequestMapping(value = "/getLicensePlate/{finOrVin}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public VehicleDetails getLicensePlateInfo(@ApiParam(value = "finOrVin for getting the license plate ", defaultValue = "WDD2221631A160411", required = true) @PathVariable(value = "finOrVin", required = true) String finOrVin
			 ) throws Exception{
		
		logger.info("Invoking  CPD service");
		ResponseEntity<VehicleDetails> vehicleInfo = cpdHandler.getVehicleInfoWithFinOrVin(finOrVin);
		logger.info("Exiting CPD service");
		
		return vehicleInfo.getBody();
		
	}
	
	@CrossOrigin
	@ApiOperation(value = "Returns the session context details details for the given SessionId")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Get session context details details service successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	 @ApiImplicitParams({
         @ApiImplicitParam(name = "X-TrackingId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header")
}) 
	@RequestMapping(value = "/getsessionContext/{sessionId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public SessionContextDetail getSessionContextDetails(@ApiParam(value = "SessionId for getting the SessionContext Details ", defaultValue = "673c7475-b368-451e-90a0-4da44bcd5f9a", required = true) @PathVariable(value = "sessionId", required = true) String sessionId
			 ) throws Exception{
		
		logger.info("Inside Get Session Context Details Service");
		
		SessionContextDetail sessionContextDetail  = sessionContextService.getSessionContextDetails(sessionId);
		return sessionContextDetail;
		
	}

}
