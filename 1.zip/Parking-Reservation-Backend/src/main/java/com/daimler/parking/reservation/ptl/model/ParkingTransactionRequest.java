package com.daimler.parking.reservation.ptl.model;

import java.io.Serializable;

import com.daimler.parking.reservation.response.BaseResponse;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ParkingTransactionRequest extends BaseResponse implements Serializable{
	
	private static final long serialVersionUID = 611838699138105348L;
	
	@ApiModelProperty(value = "parkingTransaction", readOnly = true)
	@JsonProperty("parkingTransaction")
	private ParkingTransaction parkingTransaction;

	public ParkingTransaction getParkingTransaction() {
		return parkingTransaction;
	}

	public void setParkingTransaction(ParkingTransaction parkingTransaction) {
		this.parkingTransaction = parkingTransaction;
	}

}
