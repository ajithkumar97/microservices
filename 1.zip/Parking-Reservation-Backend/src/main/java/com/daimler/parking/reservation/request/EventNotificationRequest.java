package com.daimler.parking.reservation.request;

import javax.validation.constraints.NotNull;

import com.daimler.parking.reservation.model.ParkingGarageAddress;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Notification Request", description = " Notification request information")
public class EventNotificationRequest {
	
	@ApiModelProperty(value="FIN ID of the car.",dataType="String",required=false)
	private String finId;
	@ApiModelProperty(value="Car entry to the garage or exit from the garage=[Entry,Exit]",dataType="String",required=true)
	@NotNull(message = "EventType is required.")
	private String eventType;
	@ApiModelProperty(value="GarageName",dataType="String",required=true)
	@NotNull(message = "Garage Name is required.")
	private String parkingFacilityName;
	@ApiModelProperty(value="GarageAddress",required=true)
	@NotNull(message = "Garage Address is required.")
	private ParkingGarageAddress address;
	@ApiModelProperty(value="StartTime",dataType="String",required=true)
	@NotNull(message = "StartTime is required.")
	private String startDateTime;
	@ApiModelProperty(value="EndTime",dataType="String",required=true)
	@NotNull(message = "EndTime is required.")
	private String endDateTime;
	@ApiModelProperty(value="Duration",dataType="String",required=true)
	@NotNull(message = "Duration is required.")
	private String duration;
	@ApiModelProperty(value="Charged By the Garage",dataType="String",required=true)
	@NotNull(message = "Price is required.")
	private String price;
	
	@JsonIgnore
	private String userId;

	/**
	 * @return the eventType
	 */
	public String getEventType() {
		return eventType;
	}
	/**
	 * @param eventType the eventType to set
	 */
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	/**
	 * @return the parkingFacilityName
	 */
	public String getParkingFacilityName() {
		return parkingFacilityName;
	}
	/**
	 * @param parkingFacilityName the parkingFacilityName to set
	 */
	public void setParkingFacilityName(String parkingFacilityName) {
		this.parkingFacilityName = parkingFacilityName;
	}
	/**
	 * @return the address
	 */
	public ParkingGarageAddress getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(ParkingGarageAddress address) {
		this.address = address;
	}
	/**
	 * @return the startDateTime
	 */
	public String getStartDateTime() {
		return startDateTime;
	}
	/**
	 * @param startDateTime the startDateTime to set
	 */
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	/**
	 * @return the endDateTime
	 */
	public String getEndDateTime() {
		return endDateTime;
	}
	/**
	 * @param endDateTime the endDateTime to set
	 */
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}
	/**
	 * @return the finId
	 */
	public String getFinId() {
		return finId;
	}
	/**
	 * @param finId the finId to set
	 */
	public void setFinId(String finId) {
		this.finId = finId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	

	

}
