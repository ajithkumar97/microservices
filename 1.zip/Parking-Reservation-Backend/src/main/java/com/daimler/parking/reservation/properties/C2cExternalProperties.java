package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "c2cExternalProperties", ignoreUnknownFields = false)
public class C2cExternalProperties {

	private String mercedesPaymentUrl;
	private String ntg6validateSessionIdUrl;
	private String ocp_Apim_Subscription_Key;
	private String sessionContextDetailsUrl;

	public String getMercedesPaymentUrl() {
		return mercedesPaymentUrl;
	}

	public void setMercedesPaymentUrl(String mercedesPaymentUrl) {
		this.mercedesPaymentUrl = mercedesPaymentUrl;
	}

	public String getNtg6validateSessionIdUrl() {
		return ntg6validateSessionIdUrl;
	}

	public void setNtg6validateSessionIdUrl(String ntg6validateSessionIdUrl) {
		this.ntg6validateSessionIdUrl = ntg6validateSessionIdUrl;
	}


	public String getOcp_Apim_Subscription_Key() {
		return ocp_Apim_Subscription_Key;
	}

	public void setOcp_Apim_Subscription_Key(String ocp_Apim_Subscription_Key) {
		this.ocp_Apim_Subscription_Key = ocp_Apim_Subscription_Key;
	}

	public String getSessionContextDetailsUrl() {
		return sessionContextDetailsUrl;
	}

	public void setSessionContextDetailsUrl(String sessionContextDetailsUrl) {
		this.sessionContextDetailsUrl = sessionContextDetailsUrl;
	}
	
	

}
