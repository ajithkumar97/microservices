package com.daimler.parking.reservation;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
//@EnableEurekaClient
//@EnableCircuitBreaker
@EnableSwagger2
@RestController
public class ParkingSpaceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingSpaceBackendApplication.class, args);
	}
	
	@Value("${swagger.api.key}")
    private String swaggerApiKey;
    
    @RequestMapping(value ="/swagger/getapikey" ,method = RequestMethod.GET)
    public boolean getApiKey(HttpServletRequest request, @RequestParam(value = "apikey", required = false) String apiKeyValue) {
        if (apiKeyValue.equals(swaggerApiKey)) {
            return true;
        } else {
            return false;
        }
    }
}
