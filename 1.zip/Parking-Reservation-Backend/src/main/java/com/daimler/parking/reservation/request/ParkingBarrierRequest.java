package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;

public class ParkingBarrierRequest extends BaseRequest {

    @NotEmpty(message = "Barrier id cannot be blank.")
    private String BarrierId;
    
    @NotEmpty(message = "Booking id cannot be blank.")
    private String BookingId;
    
    private String barrierReason;

    public String getBarrierId() {
		return BarrierId;
	}

	public void setBarrierId(String BarrierId) {
		this.BarrierId = BarrierId;
	}

	public String getBarrierReason() {
        return barrierReason;
    }

    public void setBarrierReason(String barrierReason) {
        this.barrierReason = barrierReason;
    }

    public String getBookingId() {
        return BookingId;
    }

    public void setBookingId(String BookingId) {
        this.BookingId = BookingId;
    }

	@Override
	public String toString() {
		return "ParkingBarrierRequest [BarrierId=" + BarrierId + ", BookingId=" + BookingId + ", barrierReason="
				+ barrierReason + "]";
	}
    
    

}
