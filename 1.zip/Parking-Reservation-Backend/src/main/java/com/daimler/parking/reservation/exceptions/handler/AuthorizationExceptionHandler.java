package com.daimler.parking.reservation.exceptions.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.core.Ordered;

import com.daimler.parking.reservation.exceptions.AuthorizationException;
import com.daimler.parking.reservation.response.BaseResponse;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@RestController
public class AuthorizationExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(AuthorizationExceptionHandler.class);
	
	@ExceptionHandler(AuthorizationException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    public BaseResponse authorizationDeniedHandler(AuthorizationException exception) {

		 logger.info("Authorization");

	        BaseResponse response = new BaseResponse();
	        response.setStatusCode("403");
	        response.setStatusMessage("User is not Authorized"+" - "+exception.getMessage());
	        return response;
    }

}
