package com.daimler.parking.reservation.exceptions.handler.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ErrorObject {
	
	@JsonProperty("errorCode")
    @ApiModelProperty("number, not string! Don't believe swaggers lies.")
	@JsonIgnoreProperties
    private ErrorCode errorCode;
	@JsonProperty("errorMessage")
    private String errorMessage;

    /**
     * Default ctor required for deserialization.
     */
    public ErrorObject() {
        // default ctor
    }

    public ErrorObject(ErrorCode errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(ErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "errorCode='" + errorCode.getValue() + "', errorMessage='" + errorMessage + "'";
    }

}