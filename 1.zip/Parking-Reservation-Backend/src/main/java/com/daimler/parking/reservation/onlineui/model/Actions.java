package com.daimler.parking.reservation.onlineui.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Actions
{
	@JsonProperty("Group")
	private String group;
	
	@JsonProperty("Name")
	private String name;

	@JsonProperty("Arguments")
	private String arguments;

	@JsonProperty("TrustLevelForExecution")
	private Integer trustLevelForExecution;

	@JsonProperty("ID")
	private Integer id;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getArguments() {
		return arguments;
	}

	public void setArguments(String arguments) {
		this.arguments = arguments;
	}

	public Integer getTrustLevelForExecution() {
		return trustLevelForExecution;
	}

	public void setTrustLevelForExecution(Integer trustLevelForExecution) {
		this.trustLevelForExecution = trustLevelForExecution;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	@Override
	public String toString() {
		return "Actions [name=" + name + ", arguments=" + arguments + ", trustLevelForExecution="
				+ trustLevelForExecution + ", id=" + id + ", group=" + group + "]";
	}

	

}
