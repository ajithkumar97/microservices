package com.daimler.parking.reservation.authorization;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

/**
 * Authorization configuration parameter
 */
@Component
@ConfigurationProperties(prefix = "authorization", ignoreUnknownFields = false)
public class AuthorizationProperties {

//    @NotNull
    private String baseUrl;
    @NotNull
    private boolean enabled;
//    @NotNull
    private int[] serviceIds;
//    @NotNull
    private String ciamHeaderName;
//    @NotNull
    private String vinHeaderName;
//    @NotNull
    private String vhpEnv;

    private BasicAuthentication basicAuth;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public int[] getServiceIds() {
        return serviceIds;
    }

    public void setServiceIds(int[] serviceIds) {
        this.serviceIds = serviceIds;
    }

    public String getCiamHeaderName() {
		return ciamHeaderName;
	}

	public void setCiamHeaderName(String ciamHeaderName) {
		this.ciamHeaderName = ciamHeaderName;
	}

	public String getVinHeaderName() {
        return vinHeaderName;
    }

    public void setVinHeaderName(String vinHeaderName) {
        this.vinHeaderName = vinHeaderName;
    }

    public String getVhpEnv() {
        return vhpEnv;
    }

    public void setVhpEnv(String vhpEnv) {
        this.vhpEnv = vhpEnv;
    }

    public BasicAuthentication getBasicAuth() {
        return basicAuth;
    }

    public void setBasicAuth(BasicAuthentication basicAuth) {
        this.basicAuth = basicAuth;
    }
}
