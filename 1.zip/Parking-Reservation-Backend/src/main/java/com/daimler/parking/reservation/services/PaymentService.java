package com.daimler.parking.reservation.services;

import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.request.PaymentRequest;
import com.daimler.parking.reservation.response.PaymentResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Component
public class PaymentService {
	
	@Autowired
	MockApiaryCallService apiaryCallService;

	public PaymentResponse addOrder(PaymentRequest paymentRequest) throws JsonParseException, JsonMappingException, IOException {
		
		PaymentResponse paymentResponse = apiaryCallService.getPaymentResponse(paymentRequest);
		/*PaymentResponse paymentResponse = new PaymentResponse();
		paymentResponse.setTxnId("T123");
		paymentResponse.setPaymentAmount("1$");
		paymentResponse.setPaymentDate("Jun 20, 2017 9:13:42 AM");*/
		return paymentResponse;

	}

	public void cancelOrder() {

	}
}
