package com.daimler.parking.reservation.model;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Slot Information", description = "Slot info got from Ampido")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Slot implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Parking Slot Id", readOnly = true)
	@JsonProperty("uuid")
	@NotEmpty(message = "uuid cannot be blank.")
	private String uuid;
	
	@ApiModelProperty(value = "Description of Parking Slot ", readOnly = true)
	@JsonProperty("description")
	private String description;
	
	@ApiModelProperty(value = "accessRestriction of Parking Slot", readOnly = true)
	@JsonProperty("accessRestriction")
	private String accessRestriction;
	
	@ApiModelProperty(value = "images of Parking Slot", readOnly = true)
	@JsonProperty("images")
	private List<Image> images;
	
	@ApiModelProperty(value = "accessMethod of Parking Slot", readOnly = true)
	@JsonProperty("accessMethod")
	private String accessMethod;
	
	@ApiModelProperty(value = "importantInformation of Parking Slot", readOnly = true)
	@JsonProperty("importantInformation")
	private String importantInformation;
	
	@ApiModelProperty(value = "exclusiveFor Parking Slot", readOnly = true)
	@JsonProperty("exclusiveFor")
	private List<String> exclusiveFor;
	
	@ApiModelProperty(value = "latitude of Parking Slot", readOnly = true)
	@JsonProperty("latitude")
	@NotEmpty(message = "latitude cannot be blank.")
	private double latitude;
	
	@ApiModelProperty(value = "longitude of Parking Slot", readOnly = true)
	@JsonProperty("longitude")
	@NotEmpty(message = "longitude cannot be blank.")
	private double longitude;
	
	@ApiModelProperty(value = "country of Parking Slot", readOnly = true)
	@JsonProperty("country")
	@NotEmpty(message = "country cannot be blank.")
	private String country;
	
	@ApiModelProperty(value = "city of Parking Slot", readOnly = true)
	@JsonProperty("city")
	@NotEmpty(message = "city cannot be blank.")
	private String city;
	
	@ApiModelProperty(value = "postalCode of Parking Slot", readOnly = true)
	@JsonProperty("postalCode")
	@NotEmpty(message = "postalCode cannot be blank.")
	private String postalCode;
	
	@ApiModelProperty(value = "streetName of Parking Slot", readOnly = true)
	@JsonProperty("streetName")
	@NotEmpty(message = "streetName cannot be blank.")
	private String streetName;
	
	@ApiModelProperty(value = "streetNumber of Parking Slot", readOnly = true)
	@JsonProperty("streetNumber")
	@NotEmpty(message = "streetNumber cannot be blank.")
	private String streetNumber;
	
	@ApiModelProperty(value = "updatedAt Information of Parking Slot", readOnly = true)
	@JsonProperty("updatedAt")
	@NotEmpty(message = "updatedAt cannot be blank.")
	private String updatedAt;
	
	@ApiModelProperty(value = "features of the Parking Slot", readOnly = true)
	@JsonProperty("features")
	private List<Feature> features;
	
	@ApiModelProperty(value = "type of Parking Slots", readOnly = true)
	@JsonProperty("type")
	@NotEmpty(message = "type cannot be blank.")
	private Type type;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAccessRestriction() {
		return accessRestriction;
	}

	public void setAccessRestriction(String accessRestriction) {
		this.accessRestriction = accessRestriction;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getAccessMethod() {
		return accessMethod;
	}

	public void setAccessMethod(String accessMethod) {
		this.accessMethod = accessMethod;
	}

	public String getImportantInformation() {
		return importantInformation;
	}

	public void setImportantInformation(String importantInformation) {
		this.importantInformation = importantInformation;
	}

	public List<String> getExclusiveFor() {
		return exclusiveFor;
	}

	public void setExclusiveFor(List<String> exclusiveFor) {
		this.exclusiveFor = exclusiveFor;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<Feature> getFeatures() {
		return features;
	}

	public void setFeatures(List<Feature> features) {
		this.features = features;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

}
