package com.daimler.parking.reservation.monitoring;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.sleuth.SpanExtractor;
import org.springframework.cloud.sleuth.SpanInjector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Configuration class for customizing Spring Sleuth.
 */
@Configuration
public class MonitoringConfig {

    @Value("${monitoring.traceId.header:X-B3-TraceId}")
    private String traceIdHeaderName;

    @Bean
    @Primary
    SpanExtractor<HttpServletRequest> customHttpServletRequestSpanExtractor() {
        return new SleuthSpanExtractor(traceIdHeaderName);
    }

    @Bean
    @Primary
    SpanInjector<HttpServletResponse> customHttpServletResponseSpanInjector() {
        return new SleuthSpanInjector(traceIdHeaderName);
    }
}


