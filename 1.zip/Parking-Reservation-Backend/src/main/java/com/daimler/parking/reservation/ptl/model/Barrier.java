package com.daimler.parking.reservation.ptl.model;

import com.fasterxml.jackson.annotation.JsonProperty;


public class Barrier {

    @JsonProperty("externalBarrierId")
    private String externalBarrierId;
    @JsonProperty("position")
    private String position;

    @JsonProperty("externalBarrierId")
    public String getExternalBarrierId() {
        return externalBarrierId;
    }

    @JsonProperty("externalBarrierId")
    public void setExternalBarrierId(String externalBarrierId) {
        this.externalBarrierId = externalBarrierId;
    }

    @JsonProperty("position")
    public String getPosition() {
        return position;
    }

    @JsonProperty("position")
    public void setPosition(String position) {
        this.position = position;
    }
}
