package com.daimler.parking.reservation.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.exceptions.AuthorizationException;
import com.daimler.parking.reservation.exceptions.MissingRequestHeaderParameterException;
import com.daimler.parking.reservation.properties.MercedesPayProperties;
import com.daimler.parking.reservation.response.CiamResponse;

@Component
public class CIAMService {

	MercedesPayProperties mercedesPayProperties;
	
	private ResourceLoader resourceLoader;
	RestTemplate restTemplate;
	
	/*@PostConstruct
	public void init() {
		System.setProperty("proxyHost", "53.88.72.33");
		System.setProperty("proxyPort", "3128");
	}*/

	@Autowired
	public CIAMService(MercedesPayProperties mercedesPayProperties, RestTemplate restTemplate, ResourceLoader resourceLoader) {
		this.mercedesPayProperties = mercedesPayProperties;
		this.restTemplate = restTemplate;
		this.resourceLoader = resourceLoader;
	}
	
	public boolean isAuthorized(HttpServletRequest request) throws HttpClientErrorException {

		CiamResponse ciamResponse = new CiamResponse();
		String ciamId = request.getHeader("CIAM_ID");
		boolean isValid = false;
		try {
			if (ciamId == null) {
				throw new MissingRequestHeaderParameterException();
			}

			final HttpHeaders headers = new HttpHeaders();
			headers.set("Accept", "application/json;charset=UTF-8");
			headers.set("CIAM_ID", ciamId);
			headers.set("Authorization", "Basic bGJwczpsYnBzX3JvY2tz");

			HttpEntity entity = new HttpEntity<>(headers);

			ResponseEntity<CiamResponse> response = createRestTemplate().exchange(mercedesPayProperties.getMercedesPaymentUrl(),
					HttpMethod.GET, entity, CiamResponse.class);

			ciamResponse = response.getBody();
			
			if (ciamResponse.getAssetStatus().equals("VALID")) {
				isValid = true;
			} else {
				throw new AuthorizationException("Invalid Mercedes Pay Account");
			}

		}

		catch (Exception e) {
				throw new AuthorizationException("Invalid Mercedes Pay Account");
		}
		return isValid;
	}
	
	private RestTemplate createRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException {

		/*
		 * 
		 * Create an SSLContext that uses the client certificate and the
		 * client-truststore.jks as the trust material (trusted CA certificates)
		 */

		Resource resource = resourceLoader.getResource(mercedesPayProperties.getTrustStorePath());
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		X509Certificate caCert = (X509Certificate) cf.generateCertificate(resource.getInputStream());

		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
		keystore.load(null);
		keystore.setCertificateEntry("caCert", caCert);

		tmf.init(keystore);

		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, tmf.getTrustManagers(), null);

		SSLConnectionSocketFactory sslSocketFactory = null;

		sslSocketFactory = new SSLConnectionSocketFactory(sslContext);

		HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslSocketFactory).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}

}
