package com.daimler.parking.reservation.services;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.request.EventNotificationRequest;
import com.daimler.parking.reservation.response.EventNotificationResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Component
public class NotificationService {
	
	@Autowired
	MockApiaryCallService apiaryCallService;

	public EventNotificationResponse addNotification(EventNotificationRequest request) throws JsonParseException, JsonMappingException, IOException {
		EventNotificationResponse response = apiaryCallService.getNotificationResponse(request);
		/*EventNotificationResponse response = new EventNotificationResponse();
		response.setNotificationId("Notified-123");*/
		return response;

	}

	public void deleteNotification() {

	}

}
