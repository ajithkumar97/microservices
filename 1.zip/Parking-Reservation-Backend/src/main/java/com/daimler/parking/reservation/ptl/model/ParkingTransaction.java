package com.daimler.parking.reservation.ptl.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
public class ParkingTransaction {

    @JsonProperty("carIdentificationId")
    private String carIdentificationId;
    
    @JsonProperty("carIdentificationType")
    private String carIdentificationType;
    
    @JsonProperty("ciamid")
    private String ciamid;
    
    @JsonProperty("startTime")
    private String startTime;
    
    @JsonProperty("endTime")
    private String endTime;
    
    @JsonProperty("externalBookingId")
    private String externalBookingId;
    
    @JsonProperty("parkingDuration")
    private Long parkingDuration;
    
    @JsonProperty("address")
    private Address address;
    
    @JsonProperty("serviceproviders")
    private Serviceproviders serviceproviders;
    
    @JsonProperty("parkingspace")
    private Parkingspace parkingspace;
    
    @JsonProperty("payments")
    private Payments payments;
    
    @JsonProperty("priceSplit")
    private String priceSplit;
    
    @JsonProperty("secretKey")
    private String secretKey;
    
    @JsonProperty("sourceRef")
    private String sourceRef;
    
    @JsonProperty("transactionStatus")
    private String transactionStatus;
    
    @JsonProperty("carIdentificationId")
    public String getCarIdentificationId() {
        return carIdentificationId;
    }

    @JsonProperty("carIdentificationId")
    public void setCarIdentificationId(String carIdentificationId) {
        this.carIdentificationId = carIdentificationId;
    }

    @JsonProperty("carIdentificationType")
    public String getCarIdentificationType() {
        return carIdentificationType;
    }

    @JsonProperty("carIdentificationType")
    public void setCarIdentificationType(String carIdentificationType) {
        this.carIdentificationType = carIdentificationType;
    }

    @JsonProperty("ciamid")
    public String getCiamid() {
        return ciamid;
    }

    @JsonProperty("ciamid")
    public void setCiamid(String ciamid) {
        this.ciamid = ciamid;
    }

    @JsonProperty("startTime")
    public String getStartTime() {
        return startTime;
    }

    @JsonProperty("startTime")
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @JsonProperty("endTime")
    public String getEndTime() {
        return endTime;
    }

    @JsonProperty("endTime")
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    @JsonProperty("externalBookingId")
    public String getExternalBookingId() {
        return externalBookingId;
    }

    @JsonProperty("externalBookingId")
    public void setExternalBookingId(String externalBookingId) {
        this.externalBookingId = externalBookingId;
    }

    @JsonProperty("parkingDuration")
    public Long getParkingDuration() {
        return parkingDuration;
    }

    @JsonProperty("parkingDuration")
    public void setParkingDuration(Long parkingDuration) {
        this.parkingDuration = parkingDuration;
    }

    @JsonProperty("address")
    public Address getAddress() {
        return address;
    }

    @JsonProperty("address")
    public void setAddress(Address address) {
        this.address = address;
    }

    @JsonProperty("serviceproviders")
    public Serviceproviders getServiceproviders() {
        return serviceproviders;
    }

    @JsonProperty("serviceproviders")
    public void setServiceproviders(Serviceproviders serviceproviders) {
        this.serviceproviders = serviceproviders;
    }

    @JsonProperty("parkingspace")
    public Parkingspace getParkingspace() {
        return parkingspace;
    }

    @JsonProperty("parkingspace")
    public void setParkingspace(Parkingspace parkingspace) {
        this.parkingspace = parkingspace;
    }

    @JsonProperty("payments")
    public Payments getPayments() {
        return payments;
    }

    @JsonProperty("payments")
    public void setPayments(Payments payments) {
        this.payments = payments;
    }

    @JsonProperty("priceSplit")
    public String getPriceSplit() {
        return priceSplit;
    }

    @JsonProperty("priceSplit")
    public void setPriceSplit(String priceSplit) {
        this.priceSplit = priceSplit;
    }

    public String getSourceRef() {
		return sourceRef;
	}

	public void setSourceRef(String sourceRef) {
		this.sourceRef = sourceRef;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@JsonProperty("secretKey")
    public String getSecretKey() {
        return secretKey;
    }

    @JsonProperty("secretKey")
    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

}
