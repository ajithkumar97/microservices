package com.daimler.parking.reservation.ptl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Image {

    @JsonProperty("url")
    private String url;


    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

}
