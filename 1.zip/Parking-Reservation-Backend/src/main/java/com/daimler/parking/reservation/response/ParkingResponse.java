package com.daimler.parking.reservation.response;

import java.util.List;

import com.daimler.parking.reservation.model.ParkingSlot;

public class ParkingResponse extends BaseResponse {
	
	 
	private List<ParkingSlot> parkingSlots;

    public List<ParkingSlot> getParkingSlots() {
		return parkingSlots;
	}

	public void setParkingSlots(List<ParkingSlot> parkingSlots) {
		this.parkingSlots = parkingSlots;
	}


    @Override
    public String toString()
    {
        return "ClassPojo [results = "+parkingSlots+"]";
    }
	
	
	

}
