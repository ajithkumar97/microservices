package com.daimler.parking.reservation.model;

import java.io.Serializable;

public class CurrentUser implements Serializable {

	private String ciamID;
	private String cpdID;
	private String firstName;
	private String lastName;

	public String getCiamID() {
		return ciamID;
	}

	public void setCiamID(String ciamID) {
		this.ciamID = ciamID;
	}

	public String getCpdID() {
		return cpdID;
	}

	public void setCpdID(String cpdID) {
		this.cpdID = cpdID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
