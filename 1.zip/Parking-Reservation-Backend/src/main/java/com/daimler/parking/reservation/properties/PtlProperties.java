package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * PTL urls parameter from application.properties file.
 */

@Component
@ConfigurationProperties(prefix = "PTL.Urls", ignoreUnknownFields = false)
public class PtlProperties {
	
	private String cancelUrl;

	public String getCancelUrl() {
		return cancelUrl;
	}

	public void setCancelUrl(String cancelUrl) {
		this.cancelUrl = cancelUrl;
	}
	

}
