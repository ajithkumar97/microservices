package com.daimler.parking.reservation.adapters.ampido;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

@Component
public class AccessToken {
	
	private String accessToken;
	private String refreshToken;
	private LocalDateTime expiringDateTime;
	private int bufferTime;
	
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public LocalDateTime getExpiringDateTime() {
		return expiringDateTime;
	}
	public void setExpiringDateTime(LocalDateTime expiringDateTime) {
		this.expiringDateTime = expiringDateTime;
	}
	public int getBufferTime() {
		return bufferTime;
	}
	public void setBufferTime(int bufferTime) {
		this.bufferTime = bufferTime;
	}
	@Override
	public String toString() {
		return "AccessToken [accessToken=" + accessToken + ", refreshToken=" + refreshToken + ", expiringDateTime="
				+ expiringDateTime + ", bufferTime=" + bufferTime + "]";
	}
	
}
