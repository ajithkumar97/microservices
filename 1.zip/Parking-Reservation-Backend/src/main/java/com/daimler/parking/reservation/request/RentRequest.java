package com.daimler.parking.reservation.request;

import java.io.Serializable;

import com.daimler.parking.reservation.model.Rent;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Rent Request", description = "Rent Request of Booking for Ampido")
@JsonIgnoreProperties(ignoreUnknown = true)
public class RentRequest extends BaseRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Rent Information", readOnly = true)
	@JsonProperty("rent")
	private Rent rent;

	public Rent getRent() {
		return rent;
	}

	public void setRent(Rent rent) {
		this.rent = rent;
	}

}
