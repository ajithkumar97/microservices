package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * AMPIDO Adapater configuration parameter.
 */

@Component
@ConfigurationProperties(prefix = "adapter.ampido", ignoreUnknownFields = false)
public class AmpidoAdapterProperties {

	private String imageUrl;
	private String clientId;
	private String clientSecret;
	private String grantType;
	private String userName;
	private String password;
	private String scope;
	private String authTokenUrl;
	private String searchSlotsUrl;
	private String parkingSpaceDetailsUrl;
	private String logourl;
	private String cancelUrl;
	private String bookingSpaceUrl;
	private String parkingTxnUrl;
	
	public String getParkingTxnUrl() {
		return parkingTxnUrl;
	}

	public void setParkingTxnUrl(String parkingTxnUrl) {
		this.parkingTxnUrl = parkingTxnUrl;
	}

	public String getBookingSpaceUrl() {
		return bookingSpaceUrl;
	}

	public void setBookingSpaceUrl(String bookingSpaceUrl) {
		this.bookingSpaceUrl = bookingSpaceUrl;
	}
	
	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getGrantType() {
		return grantType;
	}

	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getAuthTokenUrl() {
		return authTokenUrl;
	}

	public void setAuthTokenUrl(String authTokenUrl) {
		this.authTokenUrl = authTokenUrl;
	}

	public String getSearchSlotsUrl() {
		return searchSlotsUrl;
	}

	public void setSearchSlotsUrl(String searchSlotsUrl) {
		this.searchSlotsUrl = searchSlotsUrl;
	}

	public String getParkingSpaceDetailsUrl() {
		return parkingSpaceDetailsUrl;
	}

	public void setParkingSpaceDetailsUrl(String parkingSpaceDetailsUrl) {
		this.parkingSpaceDetailsUrl = parkingSpaceDetailsUrl;
	}

	public String getLogourl() {
		return logourl;
	}

	public void setLogourl(String logourl) {
		this.logourl = logourl;
	}

	public String getCancelUrl() {
		return cancelUrl;
	}

	public void setCancelUrl(String cancelUrl) {
		this.cancelUrl = cancelUrl;
	}
	
	

}
