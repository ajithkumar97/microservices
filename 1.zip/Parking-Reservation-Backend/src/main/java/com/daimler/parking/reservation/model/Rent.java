package com.daimler.parking.reservation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Rent Parameter", description = "Rent Parameter of Booking for Ampido")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Rent {
	
	@ApiModelProperty(value = "Parking space slotUuId", readOnly = true)
	@JsonProperty("slotUuid")
//	@NotEmpty(message = "Slot Id cannot be blank.")
	private String slotUuid;

	@ApiModelProperty(value = "startTime", readOnly = true)
	@JsonProperty("startTime")
//	@NotEmpty(message = "startTime cannot be blank.")
	private String startTime;

	@ApiModelProperty(value = "End Time", readOnly = true)
	@JsonProperty("endTime")
//	@NotEmpty(message = "endTime cannot be blank.")
	private String endTime;

	@ApiModelProperty(value = "licencePlate of the vehicle", readOnly = true)
	@JsonProperty("licencePlate")
//	@NotEmpty(message = "licencePlate cannot be blank.")
	private String licencePlate;

	public String getLicencePlate() {
		return licencePlate;
	}

	public void setLicencePlate(String licencePlate) {
		this.licencePlate = licencePlate;
	}

	public String getSlotUuid() {
		return slotUuid;
	}

	public void setSlotUuid(String slotUuid) {
		this.slotUuid = slotUuid;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


}
