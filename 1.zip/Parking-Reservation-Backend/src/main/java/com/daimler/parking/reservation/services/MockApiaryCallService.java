package com.daimler.parking.reservation.services;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.request.EventNotificationRequest;
import com.daimler.parking.reservation.request.PaymentRequest;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.EventNotificationResponse;
import com.daimler.parking.reservation.response.PaymentResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MockApiaryCallService {

	public RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());

	final String PAYMENT_URI = "http://private-5edbd-paymentapi26.apiary-mock.com/paymentService";
	final String BOOKING_URI = "http://private-e44ac-bookingspace.apiary-mock.com/bookParkingSpace";
	final String NOTIFICATION_URI = "https://private-286589-notificationapi19.apiary-mock.com/notificationService";

	
	/* un comment below if you are wokring on Daimler netwrk
	@PostConstruct
	public void init() {
		System.setProperty("proxyHost", "53.88.72.33");
		System.setProperty("proxyPort", "3128");
	}
  */
	
/*	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate(getClientHttpRequestFactory());
	}*/

	public PaymentResponse getPaymentResponse(PaymentRequest paymentRequest) throws JsonParseException, JsonMappingException, IOException {

/*		System.setProperty("proxyHost", "53.88.72.33");
		System.setProperty("proxyPort", "3128");*/
		ResponseEntity<String> response = restTemplate.getForEntity(PAYMENT_URI, String.class);

		PaymentResponse paymentResponse = new PaymentResponse();
		// Gson gson = new Gson();
		if (response.getStatusCode().equals(HttpStatus.OK)) {
			ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, false);
			paymentResponse = mapper.readValue(response.getBody(), PaymentResponse.class);
		}
		return paymentResponse;

	}

	public EventNotificationResponse getNotificationResponse(EventNotificationRequest request)
			throws JsonParseException, JsonMappingException, IOException {

/*		System.setProperty("proxyHost", "53.88.72.33");
		System.setProperty("proxyPort", "3128");*/
		ResponseEntity<String> response = restTemplate.getForEntity(NOTIFICATION_URI, String.class);

		EventNotificationResponse notificationResponse = new EventNotificationResponse();
		// Gson gson = new Gson();
		if (response.getStatusCode().equals(HttpStatus.OK)) {
			ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);;
			notificationResponse = mapper.readValue(response.getBody(), EventNotificationResponse.class);
		}
		return notificationResponse;

	}

	public BookingDetails getBookingResponse(BookingRequest bookingRequest) throws JsonParseException, JsonMappingException, IOException {
/*		System.setProperty("proxyHost", "53.88.72.33");
		System.setProperty("proxyPort", "3128");*/
		ResponseEntity<String> response = restTemplate.getForEntity(BOOKING_URI, String.class);

		BookingDetails bookingDetails = new BookingDetails();
		// Gson gson = new Gson();
		if (response.getStatusCode().equals(HttpStatus.OK)) {
			ObjectMapper mapper = new ObjectMapper()
			        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			bookingDetails = mapper.readValue(response.getBody(), BookingDetails.class);
		}
		return bookingDetails;
	}

	private static ClientHttpRequestFactory getClientHttpRequestFactory() {
		int timeout = 5000;
		HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		clientHttpRequestFactory.setConnectTimeout(timeout);
		return clientHttpRequestFactory;
	}

}
