package com.daimler.parking.reservation.security;


import com.daimler.parking.reservation.properties.C2cUserRolesProperties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class CustomWebSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {
    
    @Autowired
    private  C2cUserRolesProperties c2cUserRolesProperties;
    
     @Override
        protected void configure(HttpSecurity http) throws Exception {
         http
         .httpBasic()
         .and()         
         .csrf().disable()
         .authorizeRequests()
         .antMatchers( "/swagger/**","/apidoc/**","/c2creservation/v1/imageprovider/**","/c2creservation/v1/getLicensePlate/**/","/c2creservation/v1/ntg/**/", "/c2creservation/v1/getsessionContext/**/").permitAll()
         .anyRequest().authenticated();
         //.antMatchers("/c2creservation/v1/accumulator/**").hasAnyRole("NTG_USER","NTG_MANGER")
        // .antMatchers("/c2creservation/v1/book/**", "/c2creservation/v1/openbarrier/**","/c2creservation/v1/imageprovider/**").hasAnyRole("MMA_MANGER","NTG_MANGER")
         //.antMatchers("/c2creservation/v1/parkinglist/**","/c2creservation/v1/parkingspace/**").hasAnyRole("NTG_USER","NTG_MANGER","MMA_MANGER","MMA_USER")
         //.antMatchers("/c2creservation/v1/cac/openbarrier/**", "/c2creservation/v1/cac/cancel/**","/c2creservation/v1/cac/parkinglist/**").hasRole("CAC_USER");
         http.logout().clearAuthentication(true);
         
        }
     
     
     @Autowired
     protected void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
         
         //Todo Need to implement with databse or Auth2 
         
         auth.inMemoryAuthentication()
                .withUser(c2cUserRolesProperties.getNtgUser().trim()).password(c2cUserRolesProperties.getNtgUserPwd().trim()).roles("NTG_USER")
             .and()
                 .withUser(c2cUserRolesProperties.getNtgmanager()).password(c2cUserRolesProperties.getNtgManagerPwd()).roles("NTG_MANGER")
             .and()
                 .withUser(c2cUserRolesProperties.getMmaUser().trim()).password(c2cUserRolesProperties.getMmaUserPwd().trim()).roles("MMA_USER")
             .and()
                 .withUser(c2cUserRolesProperties.getMmamanager().trim()).password(c2cUserRolesProperties.getMmaManagerPwd().trim()).roles("MMA_MANAGER")
             .and()
                 .withUser(c2cUserRolesProperties.getMmcpUser().trim()).password(c2cUserRolesProperties.getMmcpUserPwd()).roles("MMCP_USER") 
              .and()
                 .withUser(c2cUserRolesProperties.getMmcpManager().trim()).password(c2cUserRolesProperties.getMmcpManagerPwd().trim()).roles("MMCP_MANGER")     
              .and()
                 .withUser(c2cUserRolesProperties.getSupportUser().trim()).password(c2cUserRolesProperties.getSupportUserPwd().trim()).roles("SUPPORT_USER")   
              .and()
                 .withUser(c2cUserRolesProperties.getSupportManager().trim()).password(c2cUserRolesProperties.getSupportManagerPwd().trim()).roles("SUPPORT_MANAGER")   
              .and()
                 .withUser(c2cUserRolesProperties.getAmpidoUser().trim()).password(c2cUserRolesProperties.getAmpidoUserPwd().trim()).roles("AMPIDO_MANAGER");   
                 
         
     }
     
     
}