package com.daimler.parking.reservation.services;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.onlineui.model.Actions;
import com.daimler.parking.reservation.onlineui.model.Events;
import com.daimler.parking.reservation.onlineui.model.ReserveParkingSpaceButton;
import com.daimler.parking.reservation.onlineui.model.Widgets;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


@Component
public class OnlineUiService {
	
	private final String version = "1.0";
	
	public ReserveParkingSpaceButton getbutonforReserveParkingSpace() throws JsonParseException, JsonMappingException, IOException
	{
		ReserveParkingSpaceButton buttonResponse = new ReserveParkingSpaceButton();
		ArrayList<Widgets> widgetsArray = new ArrayList<Widgets>();
		ArrayList<Events> eventsArray = new ArrayList<Events>();
		ArrayList<Actions> actionsArray = new ArrayList<Actions>();

		
		Actions actions =  new Actions();		
		actions.setGroup("CCC");
		actions.setId(1);
		actions.setName("ShowWidget");
		actions.setTrustLevelForExecution(0);
		actions.setArguments("{\"RestRequest\":{\"Type\":\"Post\",\"Endpoint\":\"C2CParkingBooking\",\"Path\":\"/sequence/1\",\"Placeholder\":[\"FormData\",\"CurrentPosition\"]}}");
		actionsArray.add(actions);
		
		Events events = new Events();
		events.setElementName("c2cParkingBooking");
		events.setType("onClick");
		events.setActions(actionsArray);
		eventsArray.add(events);
		
		Widgets widgets = new Widgets();
		widgets.setName("C2CParkingBooking.button");
		widgets.setUid("1d3af015-2da7-47ff-9b3f-fa4c07b7b20f");
		widgets.setVersion(version);
		widgets.setWidgetData("{\"buttons\":[{\"id\":\"c2cParkingBooking\",\"type\":\"c2cParkingBooking\"}]}");
		widgets.setEvents(eventsArray);
		widgetsArray.add(widgets);
		
		buttonResponse.setWidgets(widgetsArray);
		buttonResponse.setUid("f7cd09a6-0dfc-473b-801f-6a2ee8052cf9");

		return buttonResponse;
	}

}
