package com.daimler.parking.reservation.response;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.daimler.parking.reservation.mapping.BookingResponseDeserializer;
//import com.daimler.parking.reservation.mapping.SlotDeserializer;
import com.daimler.parking.reservation.model.Barrier;
import com.daimler.parking.reservation.model.Slot;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Booking Response", description = "Booking Response from Ampido")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonDeserialize(using = BookingResponseDeserializer.class)
public class BookingResponse extends BaseResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Booking Id", readOnly = true)
	@JsonProperty("uuid")
	@NotEmpty(message = "uuid cannot be blank.")
	private String uuid;

	@ApiModelProperty(value = "externalUuid", readOnly = true)
	@JsonProperty("externalUuid")
	private String externalUuid;

	@ApiModelProperty(value = "startTime for booking Parking Slot", readOnly = true)
	@JsonProperty("startTime")
	@NotEmpty(message = "startTime cannot be blank.")
	private String startTime;

	@ApiModelProperty(value = "endTime for booking Parking Slot", readOnly = true)
	@JsonProperty("endTime")
	@NotEmpty(message = "endTime cannot be blank.")
	private String endTime;

	@ApiModelProperty(value = "licencePlate of Vehicle for booking Parking Slot", readOnly = true)
	@JsonProperty("licencePlate")
	@NotEmpty(message = "licencePlate cannot be blank.")
	private String licencePlate;

	@ApiModelProperty(value = "cancelledAt", readOnly = true)
	@JsonProperty("cancelledAt")
	private String cancelledAt;

	@ApiModelProperty(value = "Secret Info given by Ampido after Booking", readOnly = true)
	@JsonProperty("secretInformation")
	private String secretInformation;

	@ApiModelProperty(value = "barriers information", readOnly = true)
	@JsonProperty("barriers")
	@NotEmpty(message = "barriers cannot be blank.")
	private List<Barrier> barriers;

	@ApiModelProperty(value = "slot information after booking", readOnly = true)
	@JsonProperty("slot")
	@NotEmpty(message = "slot cannot be blank.")
	// @JsonDeserialize(using=SlotDeserializer.class)
	private Slot slot;

	@ApiModelProperty(value = "company information of the slot provider", readOnly = true)
	@JsonProperty("company")
	@NotEmpty(message = "company cannot be blank.")
	private String company;

	@ApiModelProperty(value = "logoUrl information of the slot provider", readOnly = true)
	@JsonProperty("logoUrl")
	@NotEmpty(message = "logoUrl cannot be blank.")
	private String logoUrl;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getExternalUuid() {
		return externalUuid;
	}

	public void setExternalUuid(String externalUuid) {
		this.externalUuid = externalUuid;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getLicencePlate() {
		return licencePlate;
	}

	public void setLicencePlate(String licencePlate) {
		this.licencePlate = licencePlate;
	}

	public String getCancelledAt() {
		return cancelledAt;
	}

	public void setCancelledAt(String cancelledAt) {
		this.cancelledAt = cancelledAt;
	}

	public String getSecretInformation() {
		return secretInformation;
	}

	public void setSecretInformation(String secretInformation) {
		this.secretInformation = secretInformation;
	}

	public List<Barrier> getBarriers() {
		return barriers;
	}

	public void setBarriers(List<Barrier> barriers) {
		this.barriers = barriers;
	}

	public Slot getSlot() {
		return slot;
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getLogoUrl() {
		return logoUrl;
	}

	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

}
