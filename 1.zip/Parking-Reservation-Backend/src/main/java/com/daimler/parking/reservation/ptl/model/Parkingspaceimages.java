package com.daimler.parking.reservation.ptl.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Parkingspaceimages {

    @JsonProperty("image")
    private List<Image> image;

    @JsonProperty("image")
    public List<Image> getImage() {
        return image;
    }

    @JsonProperty("image")
    public void setImage(List<Image> image) {
        this.image = image;
    }


}
