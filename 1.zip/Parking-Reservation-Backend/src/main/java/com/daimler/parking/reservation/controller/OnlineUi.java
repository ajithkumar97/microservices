package com.daimler.parking.reservation.controller;

import com.daimler.parking.reservation.onlineui.model.ReserveParkingSpaceButton;
import com.daimler.parking.reservation.services.OnlineUiService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
@Api(value = "NTG Online UI", description = "NTG Online UI Endpoints for C2C Reservation")
@RequestMapping(value = "/c2creservation/v1/ntg")

public class OnlineUi {

    private static final Logger logger = LoggerFactory.getLogger( OnlineUi.class );

    @Autowired
    OnlineUiService onlineUiService;

    @ApiOperation(value = "Returns sequence/0 for C2CReservation.buttons")
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Operation is done successfully without errors."),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."), @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.") })

    @ApiImplicitParams({
            @ApiImplicitParam(name = "X-B3-TraceId", value = "A globally unique id, used for tracing purposes. Must be a valid long number in hexadecimal format.", required = false, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "X-SessionId", value = "Session Id of the CAR", required = false, dataType = "string", paramType = "header", defaultValue = "673c7475-b368-451e-90a0-4da44bcd5f9a") })
    @RequestMapping(value = "/booking/sequence/0", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ReserveParkingSpaceButton getsequence0() throws Exception {
        final ReserveParkingSpaceButton buttonResponse = onlineUiService.getbutonforReserveParkingSpace();
        return buttonResponse;
    }
}
