package com.daimler.parking.reservation.ptl.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Payments {

    @JsonProperty("charge")
    private Double charge;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("currencySymbol")
    private String currencySymbol;
    @JsonProperty("paymentDate")
    private Date paymentDate;
    @JsonProperty("paymentReference")
    private String paymentReference;
    @JsonProperty("serviceFee")
    private Double serviceFee;
    @JsonProperty("vatAmount")
    private Double vatAmount;
    @JsonProperty("vatRate")
    private Double vatRate;

    @JsonProperty("charge")
    public Double getCharge() {
        return charge;
    }

    @JsonProperty("charge")
    public void setCharge(Double charge) {
        this.charge = charge;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("currencySymbol")
    public String getCurrencySymbol() {
        return currencySymbol;
    }

    @JsonProperty("currencySymbol")
    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    @JsonProperty("paymentDate")
    public Date getPaymentDate() {
        return paymentDate;
    }

    @JsonProperty("paymentDate")
    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    @JsonProperty("paymentReference")
    public String getPaymentReference() {
        return paymentReference;
    }

    @JsonProperty("paymentReference")
    public void setPaymentReference(String paymentReference) {
        this.paymentReference = paymentReference;
    }

    @JsonProperty("serviceFee")
    public Double getServiceFee() {
        return serviceFee;
    }

    @JsonProperty("serviceFee")
    public void setServiceFee(Double serviceFee) {
        this.serviceFee = serviceFee;
    }

    @JsonProperty("vatAmount")
    public Double getVatAmount() {
        return vatAmount;
    }

    @JsonProperty("vatAmount")
    public void setVatAmount(Double vatAmount) {
        this.vatAmount = vatAmount;
    }

    @JsonProperty("vatRate")
    public Double getVatRate() {
        return vatRate;
    }

    @JsonProperty("vatRate")
    public void setVatRate(Double vatRate) {
        this.vatRate = vatRate;
    }

}
