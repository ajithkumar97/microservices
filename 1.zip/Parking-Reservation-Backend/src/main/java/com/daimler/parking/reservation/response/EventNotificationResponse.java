package com.daimler.parking.reservation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Response", description = "Notification Response")
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventNotificationResponse {

	@ApiModelProperty(value = "Notification Response Message Id", readOnly = true)
	@JsonProperty("notificationId")
	private String notificationId;
	
	@ApiModelProperty(value = "Errors Code", readOnly = true)
	@JsonProperty("errorCode")
//	@JsonIgnoreProperties
	private String errorCode;
	
	@ApiModelProperty(value = "Errors Details", readOnly = true)
	@JsonProperty("errorMessage")
//	@JsonIgnoreProperties
	private String errorMessage;



	/**
	 * @return the notificationId
	 */
	public String getNotificationId() {
		return notificationId;
	}

	/**
	 * @param notificationId the notificationId to set
	 */
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	
}
