package com.daimler.parking.reservation.adapters.ampido;

import java.io.IOException;
import java.net.URI;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.daimler.parking.reservation.ptl.model.Image;
import com.daimler.parking.reservation.constants.ApplicationContants;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.model.ParkingSpace;
import com.daimler.parking.reservation.model.ParkingSpaceResponse;
import com.daimler.parking.reservation.properties.AmpidoAdapterProperties;
import com.daimler.parking.reservation.properties.PtlProperties;
import com.daimler.parking.reservation.ptl.model.Address;
import com.daimler.parking.reservation.ptl.model.Barrier;
import com.daimler.parking.reservation.ptl.model.ParkingTransaction;
import com.daimler.parking.reservation.ptl.model.ParkingTransactionRequest;
import com.daimler.parking.reservation.ptl.model.Parkingspace;
import com.daimler.parking.reservation.ptl.model.Parkingspacebarrier;
import com.daimler.parking.reservation.ptl.model.Parkingspaceimages;
import com.daimler.parking.reservation.ptl.model.Serviceproviders;
import com.daimler.parking.reservation.request.AccessTokenRequest;
import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.request.CancellationRequest;
import com.daimler.parking.reservation.request.RefreshTokenRequest;
import com.daimler.parking.reservation.request.RentRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.BookingResponse;
import com.daimler.parking.reservation.response.CancellationResponse;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;
import com.daimler.parking.reservation.response.TokenResponse;
import com.daimler.parking.reservation.services.MockApiaryCallService;
import com.daimler.parking.reservation.utils.EncryptionUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.applicationinsights.TelemetryClient;
import com.microsoft.applicationinsights.telemetry.Duration;

@Component
public class AmpidoAdapter {

	private StopWatch stopWatch = new StopWatch();
	private Duration responseTime;
	private static final Logger logger = LoggerFactory.getLogger(AmpidoAdapter.class);
	
	@Autowired
	AmpidoAdapterProperties ampidoAdapterProperties;
	
	@Autowired
	PtlProperties ptlProperties;
	
	@Autowired
	MockApiaryCallService apiaryCallService;

	@Autowired
	AccessToken accessToken;
	
	@Autowired
	RestTemplate restTemplate;
	
//	@PostConstruct
//    public void init() {
//        System.setProperty("proxyHost", "53.88.72.33");
//        System.setProperty("proxyPort", "3128");
//    }
	
	/**
	 * @param rentRequest
	 * @return
	 * @throws JsonProcessingException
	 */
	public BaseResponse bookParkingSpace(RentRequest rentRequest) throws JsonProcessingException {

		logger.info("Entered bookParkingSpace method");

		StopWatch stopWatch = new StopWatch();
		BaseResponse baseResponse = new BaseResponse();
		String accessToken = getAccessToken();
		logger.info("accesstoken is:::" + accessToken);
		if (null == accessToken) {
			logger.info("AccesToken is null");
			baseResponse.setStatusCode("500");
			baseResponse.setStatusMessage("Could not book parking space, please try again");
		} else {

			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Content-Type", "application/json;charset=UTF-8");
			headers.set("Authorization", "Bearer " + accessToken);

			HttpEntity<RentRequest> entity = new HttpEntity<>(rentRequest, headers);

			UriComponentsBuilder builder = UriComponentsBuilder
					.fromHttpUrl(ampidoAdapterProperties.getBookingSpaceUrl());

			URI uri = builder.build().toUri();
			stopWatch.reset();
			logger.info("Booking Space URI for ampido::" + uri);
			stopWatch.start();

			logger.info("Hitting ampido for booking the Parking Spaces:::" + LocalDateTime.now());
			
			ResponseEntity<BookingResponse> response = restTemplate.exchange(uri, HttpMethod.POST, entity,
					BookingResponse.class);
			stopWatch.stop();
			logger.info("Got response of booking after hitting Ampido:::" + LocalDateTime.now());
			
            responseTime = new Duration(stopWatch.getTime());
            TelemetryClient telemetry = new TelemetryClient();
            telemetry.trackDependency("Ampido API", " Ampido Booking Service API ",responseTime, true);

            
			if (null != response) {
				ObjectMapper mapper = new ObjectMapper();
				logger.info("Response from AMPIDO after booking ==" + mapper.writeValueAsString(response));
				BookingResponse bookingResForPTL = response.getBody();

				HttpHeaders headersForPTL = new HttpHeaders();

				headersForPTL.setContentType(MediaType.APPLICATION_JSON);
				headersForPTL.set("Content-Type", "application/json;charset=UTF-8");

				UriComponentsBuilder builderForPTL = UriComponentsBuilder.fromHttpUrl(ampidoAdapterProperties.getParkingTxnUrl());

				URI uriForPTL = builderForPTL.build().toUri();
				logger.info("Adding reservation URI for PTL::" + uriForPTL);

				ParkingTransactionRequest parkingTransactionRequest = createPayLoadForPTL(bookingResForPTL);

				logger.info("Payload for adding reservation of PTL::"
						+ mapper.writeValueAsString(parkingTransactionRequest));

				HttpEntity<ParkingTransactionRequest> entityForPTL = new HttpEntity<>(parkingTransactionRequest,
						headersForPTL);

				stopWatch.reset();

				logger.info("Hitting PTL for adding the reservation::" + LocalDateTime.now());
				
				
				stopWatch.start();
				try {
					ResponseEntity<BaseResponse> responseFromPTL = restTemplate.exchange(uriForPTL, HttpMethod.POST,
							entityForPTL, BaseResponse.class);
					if (responseFromPTL.getStatusCode().equals(HttpStatus.OK)) {
						logger.info("Response from PTL after booking ==" + responseFromPTL);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				logger.info("Got response of booking after hitting PTL:::" + LocalDateTime.now());

			}
			if (null == response.getBody()) {

				logger.warn("No parking spaces found => Ampido didnt provide any ");
				baseResponse.setStatusCode("204");
				baseResponse.setStatusMessage("No parking spaces found.");
			} else {
				//baseResponse = response.getBody();
				baseResponse.setStatusCode("200");
				baseResponse.setStatusMessage("Successful");
			}
		}
		stopWatch.stop();

		
		TelemetryClient telemetry = new TelemetryClient();
        telemetry.trackDependency("Parking Transaction Service API", " Add Reservation",responseTime, true);
        
		return baseResponse;

	}
	

	public void openParkingBarrier(String TransactionId) {

	}

	public void cancelBooking(String TransactionId) {

	}

	/**
	 * Returns the access token used for authorization.
	 *
	 * @param grant
	 *            Type: <String> # To differentiate if it is first time getting
	 *            the access token or refreshing the expired token
	 * @param user
	 *            name: <String> # If first time,provide valid username
	 * @param password:
	 *            <String> # If first time,provide valid password
	 * @param refresh
	 *            token: <INTEGER> # If in case token is expired,pass the
	 *            refresh token value
	 * @param client
	 *            Id: <String> # Client Id
	 * @param client
	 *            secret: <ISO 8601> # client secret value
	 * 
	 * @return AccessToken
	 * 
	 **/
	public String getAccessToken() {

		logger.info("Invoking service  getAccessToken");

		TokenResponse accessTokenResponse = new TokenResponse();

		if(null == accessToken.getRefreshToken())
		{
			//Here get accessToken, refresh token using username and password(Owner credential flow)

			AccessTokenRequest accessTokenRequest = new AccessTokenRequest();
			accessTokenRequest.setClient_id(ampidoAdapterProperties.getClientId().trim());
			accessTokenRequest.setClient_secret(ampidoAdapterProperties.getClientSecret().trim());
			accessTokenRequest.setGrant_type(ampidoAdapterProperties.getGrantType().trim());
			accessTokenRequest.setPassword(ampidoAdapterProperties.getPassword().trim());
			accessTokenRequest.setUsername(ampidoAdapterProperties.getUserName().trim());
			accessTokenRequest.setScope(ampidoAdapterProperties.getScope().trim());

//			RestTemplate restTemplate = new RestTemplate();

			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Content-Type", "application/json;charset=UTF-8");

			HttpEntity<AccessTokenRequest> entity = new HttpEntity<>(accessTokenRequest, headers);

			logger.info("Hitting ampiod for getting accessToken -> ");
			stopWatch.start();
			ResponseEntity<TokenResponse> response  = restTemplate.exchange(ampidoAdapterProperties.getAuthTokenUrl(), HttpMethod.POST, entity, TokenResponse.class);
			stopWatch.stop();
			accessTokenResponse = response.getBody();
		
			if(null != accessTokenResponse) {
			logger.info("Recieved  accessToken from AMPIDO for first time....");
			logger.debug("Recieved  accessToken from AMPIDO for first time...."+accessTokenResponse.toString());
			}
			
			accessToken.setAccessToken(accessTokenResponse.getAccess_token());
			accessToken.setRefreshToken(accessTokenResponse.getRefresh_token());
			accessToken.setBufferTime(accessTokenResponse.getExpires_in());
			accessToken.setExpiringDateTime(LocalDateTime.now());
			
			responseTime = new Duration(stopWatch.getTime());
			TelemetryClient telemetry = new TelemetryClient();
			telemetry.trackDependency("Ampido", "GET Access Token",responseTime, true);
			return accessToken.getAccessToken();
	
		}

		// check if time expired, if not return same accessToken
		long timeDifference = ChronoUnit.SECONDS.between(accessToken.getExpiringDateTime(), LocalDateTime.now());
		
		logger.debug("TimeDifference ->"+timeDifference + ", buffertime in accestoken is "+accessToken.getBufferTime());
		
		if((null != accessToken.getRefreshToken()) && (timeDifference>(accessToken.getBufferTime()-70)))
		{
			//			Get accesstoken using refresh token
			RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest();
			refreshTokenRequest.setGrant_type("refresh_token");		
			refreshTokenRequest.setRefresh_token(accessToken.getRefreshToken());
			refreshTokenRequest.setClient_secret(ampidoAdapterProperties.getClientSecret().trim());
			refreshTokenRequest.setClient_id(ampidoAdapterProperties.getClientId().trim());

//			RestTemplate restTemplate = new RestTemplate();

			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Content-Type", "application/json;charset=UTF-8");

			HttpEntity<RefreshTokenRequest> entity = new HttpEntity<>(refreshTokenRequest, headers);
			stopWatch.reset();
			logger.debug("Hitting ampiod for getting accessToken -> "+LocalDateTime.now());
			stopWatch.start();
			ResponseEntity<TokenResponse> response  = restTemplate.exchange(ampidoAdapterProperties.getAuthTokenUrl(), HttpMethod.POST, entity, TokenResponse.class);
			stopWatch.stop();
			
			logger.debug("Got token from ampiod -> "+LocalDateTime.now());
			
			accessTokenResponse = response.getBody();

			logger.debug("Ampido: Getting accessToken using refreshToken...(expired!)...."+accessTokenResponse.toString());	

			accessToken.setAccessToken(accessTokenResponse.getAccess_token());
			accessToken.setRefreshToken(accessTokenResponse.getRefresh_token());
			accessToken.setBufferTime(accessTokenResponse.getExpires_in());
			accessToken.setExpiringDateTime(LocalDateTime.now());
			
			responseTime = new Duration(stopWatch.getTime());
			TelemetryClient telemetry = new TelemetryClient();
			
			telemetry.trackDependency("Ampido", "Get Access Token",responseTime, true);
			
			logger.info(accessToken.getAccessToken());
			
			return accessToken.getAccessToken(); 
		}

		if(null != accessToken) {
		logger.info("Exiting  service  getAccessToken is generation is SUCCESS ");	
		}else {
			logger.info("Exiting  service  getAccessToken is generation is FAILURE ");	
		}

		return accessToken.getAccessToken();

	}

	/*** Live response from ampido
	 * Returns parkingSpaceList 
	 * @param latitudeTopLeft
	 * @param longitudeTopLeft
	 * @param latitudeBottomRight
	 * @param longitudeBottomRight
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */

	public ParkingSpaceListResponse getParkingListFromAmpido(double latitudeTopLeft, double longitudeTopLeft,
			double latitudeBottomRight, double longitudeBottomRight, String startTime, String endTime) throws JsonParseException, JsonMappingException, IOException {
		
		
	    logger.info("Invoking  getParkingListFromAmpido Adapter service ");

		ParkingSpaceListResponse parkingSpaceListResponse  = new ParkingSpaceListResponse();

		try {
		double latitude = (latitudeTopLeft + latitudeBottomRight)/2;
		double longitude = (longitudeTopLeft + longitudeBottomRight)/2;


//		RestTemplate restTemplate = new RestTemplate();

		String accessToken = getAccessToken();
		if (null ==accessToken )
		{
			logger.info("AccesToken is null");
			parkingSpaceListResponse.setStatusCode("500");
			parkingSpaceListResponse.setStatusMessage("Could not fetch parking spaces, please try again");
		}
		else{
			String boundingBox = new StringBuilder(String.valueOf(latitudeTopLeft)).append(",").append(longitudeTopLeft).append(",")
					.append(latitudeBottomRight).append(",").append(longitudeBottomRight).toString();
			
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Content-Type", "application/json;charset=UTF-8");   
			headers.set("Authorization", "Bearer "+accessToken);

			HttpEntity entity = new HttpEntity(headers);

			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(ampidoAdapterProperties.getSearchSlotsUrl().trim())
					.queryParam("bounds", boundingBox)
					.queryParam("start_time", startTime)
					.queryParam("end_time", endTime);
//					.queryParam("latitude", latitude)
//					.queryParam("longitude", longitude)
			URI uri = builder.build().encode().toUri();

			
			stopWatch.reset();
			logger.debug("Hitting ampido for getting Parking Spaces"+LocalDateTime.now());
			stopWatch.start();
			ResponseEntity<ParkingSpaceListResponse> response  = restTemplate.exchange(uri, HttpMethod.GET, entity, ParkingSpaceListResponse.class);
			stopWatch.stop();
			logger.debug("Got response from response"+LocalDateTime.now());
			if(null == response.getBody()) {
						
				logger.warn("No parkign spaces found => Ampido didnt provide any ");
				List<ParkingSpace> parkingSpaces = new ArrayList<ParkingSpace>();				
				parkingSpaceListResponse.setStatusCode("204");
				parkingSpaceListResponse.setStatusMessage("No parking spaces found.");
				parkingSpaceListResponse.setParkingSpaces(parkingSpaces);
			}
			else{
				parkingSpaceListResponse = response.getBody();
				parkingSpaceListResponse.setStatusCode("200");
				parkingSpaceListResponse.setStatusMessage("Successful");
				responseTime = new Duration(stopWatch.getTime());
				TelemetryClient telemetry = new TelemetryClient();
				telemetry.trackDependency("Ampido", "Get Parking Space List from ampido",responseTime, true);
			}
		} 
		
		 logger.info("Time Taken to execute Ampido Search API is ==="+ stopWatch.getTime()+"  milliseconds" );
		 
		 
		}catch (Exception e) { 
			TelemetryClient telemetry = new TelemetryClient();
			telemetry.trackDependency("Ampido", "Get Parking Space List from ampido",responseTime, false);
			logger.info("General error in getParkingListFromAmpido"+e.getMessage());
			e.printStackTrace();
			throw e;
		}
		
		logger.info("Exiting getParkingListFromAmpido Adapter Service" );
		
		return parkingSpaceListResponse;
	}
	
	
	
	/**
	 * @param uuid
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws Exception 
	 */
	public ParkingSpaceResponse getParkingSpace(String uuid, String startTime, String endTime) throws Exception {

		logger.info("Entered getParkingSpace Details  Service");
	    
	    ParkingSpaceResponse parkingSpaceResponse  = new ParkingSpaceResponse();

		String accessToken = getAccessToken();
		if (null ==accessToken )
		{
			logger.info("AccesToken is null");
			parkingSpaceResponse.setStatusCode("500");
			parkingSpaceResponse.setStatusMessage("Could not fetch parking space, please try again");
		}
		else{
			String parkingSpaceUrlWithUUID = new StringBuilder(ampidoAdapterProperties.getParkingSpaceDetailsUrl()).append("/").append(uuid).toString();
			
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Content-Type", "application/json;charset=UTF-8");   
			headers.set("Authorization", "Bearer "+accessToken);

			HttpEntity entity = new HttpEntity(headers);

			UriComponentsBuilder builder;
			if(startTime != null && endTime!= null )
			{
			 builder = UriComponentsBuilder.fromHttpUrl(parkingSpaceUrlWithUUID)
					.queryParam("start_time", startTime)
					.queryParam("end_time", endTime);
			}
			else{
				 builder = UriComponentsBuilder.fromHttpUrl(parkingSpaceUrlWithUUID);
			}
			
			URI uri = builder.build().toUri();
			logger.info("URI for ampido::"+uri);
			
			stopWatch.reset();			
			logger.info("Hitting ampido for getting Parking Spaces");
			stopWatch.start();
			ResponseEntity<ParkingSlot> response  = restTemplate.exchange(uri, HttpMethod.GET, entity, ParkingSlot.class);
			stopWatch.stop();
			
			if(null == response.getBody()) {
				logger.warn("No parking spaces found => Ampido didnt provide any ");
				parkingSpaceResponse.setStatusCode("204");
				parkingSpaceResponse.setStatusMessage("No parking spaces found.");
			}
			else{
				logger.info("Got response from response after hitting Ampido");
				parkingSpaceResponse.setParkingSpace(response.getBody());
				parkingSpaceResponse.setLogoUrl(getImageURL(ampidoAdapterProperties.getLogourl().trim()));
				parkingSpaceResponse.setStatusCode("200");
				parkingSpaceResponse.setStatusMessage("Successful");	
				responseTime = new Duration(stopWatch.getTime());
				TelemetryClient telemetry = new TelemetryClient();
				telemetry.trackDependency("Ampido", "Get Parking Space Details from ampido",responseTime, true);
			}
		}
	    
		logger.info("Exiting getParkingSpace Details  service");
		
		return parkingSpaceResponse;
	}

	public BaseResponse cancelReservedParkingSpace(CancellationRequest cancellationRequest)
	{
		BaseResponse cancleBaseResponse = new BaseResponse();
		String accessToken = getAccessToken();

		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Content-Type", "application/json;charset=UTF-8");   
		headers.set("Authorization", "Bearer "+accessToken);

		HttpEntity entity = new HttpEntity(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(ampidoAdapterProperties.getCancelUrl().trim()
				.concat("/"+cancellationRequest.getBookingId()));					
		URI uri = builder.build().encode().toUri();

		logger.debug("Hitting ampido for canceling reserved Parking Space at "+LocalDateTime.now()
		+" with accessToken "+accessToken+" and booking ID "+ cancellationRequest.getBookingId());

		stopWatch.reset();
		stopWatch.start();
		ResponseEntity<String> response  = restTemplate.exchange(uri, HttpMethod.DELETE, entity,String.class);
		stopWatch.stop();
		responseTime = new Duration(stopWatch.getTime());
		TelemetryClient telemetry = new TelemetryClient();
		telemetry.trackDependency("Ampido", "Cancel reserved parking space",responseTime, true);

		if(response.getBody()!=null)
			logger.info("Cancel response body from ampido "+response.getBody().toString());

		if(response.getStatusCodeValue()==204)
		{			
			logger.info("Cancel suuccessful, Cancel response code from ampido is "+response.getStatusCodeValue() );
			addCancelToPTL(cancellationRequest);
			cancleBaseResponse.setStatusCode("200");
			cancleBaseResponse.setStatusMessage("Cancelled is done successfully");		
		}
		else {
			logger.info("Unprocessable request, Status code from ampiod is "+response.getStatusCodeValue());
			cancleBaseResponse.setStatusCode("422");
			cancleBaseResponse.setStatusMessage("Booking Id is not valid, unable to cancel the reserved parking space");
		}

		return cancleBaseResponse;	
	}
	
	/**
	 * Update status in database to cancelled
	 * @param cancellationRequest
	 */
	private void addCancelToPTL(CancellationRequest cancellationRequest) {
		logger.info("Updating PTL database for cancel request "+cancellationRequest.toString() );
		
		HttpEntity entity = new HttpEntity(cancellationRequest);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(ptlProperties.getCancelUrl());
		URI uri = builder.build().encode().toUri();

		stopWatch.reset();
		logger.info("Hitting PTL database to update cancelling"+LocalDateTime.now());
		stopWatch.start();
		ResponseEntity<String> response  = restTemplate.exchange(uri, HttpMethod.DELETE, entity,String.class);
		stopWatch.stop();
		responseTime = new Duration(stopWatch.getTime());
		TelemetryClient telemetry = new TelemetryClient();
		telemetry.trackDependency("Database", "Cancelling booked Parking Space",responseTime, true);
		logger.info("Cancel update in PTL response code"+response.getStatusCode());
	}

	public String getImageURL(String url) throws Exception {
		
		logger.debug("Hitting ampido for getting Parking Spaces Images URL"+url);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(ampidoAdapterProperties.getImageUrl()).queryParam("ampidoURL", EncryptionUtils.encryptText(url));
		String uri = builder.build().toString();
		logger.debug("After hitting ampido the parking space image url is::"+uri);
		
		return uri;
	}
	
	private ParkingTransactionRequest createPayLoadForPTL(BookingResponse bookingResForPTL) {

		ParkingTransactionRequest parkingTransactionRequest = new ParkingTransactionRequest();
		ParkingTransaction parkingTransaction = new ParkingTransaction();
		Serviceproviders serviceproviders = new Serviceproviders();
		Address address = new Address();
		address.setCity(bookingResForPTL.getSlot().getCity());
		address.setCountry(bookingResForPTL.getSlot().getCountry());
		address.setZipCode(bookingResForPTL.getSlot().getPostalCode());
		serviceproviders.setName(bookingResForPTL.getCompany());
		serviceproviders.setCorporateForm(bookingResForPTL.getLogoUrl());
		parkingTransaction.setExternalBookingId(bookingResForPTL.getUuid());
		parkingTransaction.setStartTime(bookingResForPTL.getStartTime());
		parkingTransaction.setSecretKey(bookingResForPTL.getSecretInformation());
		parkingTransaction.setCarIdentificationType(bookingResForPTL.getLicencePlate());
		parkingTransaction.setEndTime(bookingResForPTL.getEndTime());
		parkingTransaction.setServiceproviders(serviceproviders);
		parkingTransaction.setTransactionStatus(ApplicationContants.TRANSACTION_STATUS);
		parkingTransaction.setAddress(address);
		Parkingspace parkingspace = new Parkingspace();
		Parkingspacebarrier parkingspacebarrier = new Parkingspacebarrier();
		List<com.daimler.parking.reservation.model.Barrier> ptlBarriers = bookingResForPTL.getBarriers();
		List<Barrier> barriers = new ArrayList<Barrier>();
		if (null != ptlBarriers) {
		
			for (com.daimler.parking.reservation.model.Barrier barrier2 : ptlBarriers) {
				
				Barrier barrier = new Barrier();
				barrier.setExternalBarrierId(barrier2.getUuid());
				barrier.setPosition(barrier2.getPosition());
				barriers.add(barrier);
			}
		}
		parkingspacebarrier.setBarriers(barriers);
		parkingspace.setParkingspacebarrier(parkingspacebarrier);
		parkingspace.setAccessMethod(bookingResForPTL.getSlot().getAccessMethod());
		parkingspace.setAccessRestriction(bookingResForPTL.getSlot().getAccessRestriction());
		parkingspace.setDescription(bookingResForPTL.getSlot().getDescription());
		parkingspace.setExternalUuid(bookingResForPTL.getSlot().getUuid());
		parkingspace.setImportantInformation(bookingResForPTL.getSlot().getImportantInformation());
		parkingspace.setLatitude(bookingResForPTL.getSlot().getLatitude());
		parkingspace.setLongitude(bookingResForPTL.getSlot().getLongitude());
		Parkingspaceimages parkingspaceimages = new Parkingspaceimages();
		List<com.daimler.parking.reservation.model.Image> ptlImages = bookingResForPTL.getSlot().getImages();

		if (null != ptlImages) {
			List<Image> images = new ArrayList<>();
			for (com.daimler.parking.reservation.model.Image image : ptlImages) {
				Image im = new Image();
				im.setUrl(image.getUrl());
				images.add(im);
				parkingspaceimages.setImage(images);
			}
		}
		parkingspace.setParkingspaceimages(parkingspaceimages);
		
		List<Feature> ptlFeatures = bookingResForPTL.getSlot().getFeatures();
		StringBuffer sb = new StringBuffer();
		if(null != ptlFeatures)
		{
			for(Feature feature:ptlFeatures)
			{
				sb.append(feature.getId()).append(":").append(feature.getName()).append(",");
			}
		}
		parkingspace.setFeatures(sb.toString().substring(0,sb.length()-1));
		
		parkingspace.setType(bookingResForPTL.getSlot().getType().getId().concat(":").concat(bookingResForPTL.getSlot().getType().getName()));
		parkingTransaction.setParkingspace(parkingspace);
		parkingTransactionRequest.setParkingTransaction(parkingTransaction);
		return parkingTransactionRequest;
	}

}
