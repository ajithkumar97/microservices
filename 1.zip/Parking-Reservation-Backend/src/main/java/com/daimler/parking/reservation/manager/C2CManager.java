package com.daimler.parking.reservation.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.handler.C2CBookingHandler;
import com.daimler.parking.reservation.properties.AmpidoAdapterProperties;
import com.daimler.parking.reservation.services.CIAMService;
import com.daimler.parking.reservation.services.CPDService;

@Component
public class C2CManager {
	
	@Autowired
	private AmpidoAdapterProperties ampidoAdapterProperties;

	@Autowired
	private AmpidoAdapter ampidoAdapter;
	
	@Autowired
	private C2CBookingHandler c2CBookingHandler;
	
	@Autowired
	private CIAMService ciamService;
	
	@Autowired
	private CPDService cpdService;
	
	public AmpidoAdapterProperties getAmpidoAdapterProperties() {
		return ampidoAdapterProperties;
	}

	public void setAmpidoAdapterProperties(AmpidoAdapterProperties ampidoAdapterProperties) {
		this.ampidoAdapterProperties = ampidoAdapterProperties;
	}

	public CPDService getCpdService() {
		return cpdService;
	}

	public void setCpdService(CPDService cpdService) {
		this.cpdService = cpdService;
	}

	public AmpidoAdapter getAmpidoAdapter() {
		return ampidoAdapter;
	}

	public void setAmpidoAdapter(AmpidoAdapter ampidoAdapter) {
		this.ampidoAdapter = ampidoAdapter;
	}

	public C2CBookingHandler getC2CBookingHandler() {
		return c2CBookingHandler;
	}

	public void setC2CBookingHandler(C2CBookingHandler c2cBookingHandler) {
		c2CBookingHandler = c2cBookingHandler;
	}

	public CIAMService getCiamService() {
		return ciamService;
	}

	public void setCiamService(CIAMService ciamService) {
		this.ciamService = ciamService;
	}
	

}
