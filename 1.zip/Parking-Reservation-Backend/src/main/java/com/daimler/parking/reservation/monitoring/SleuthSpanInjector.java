package com.daimler.parking.reservation.monitoring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.SpanInjector;

import javax.servlet.http.HttpServletResponse;

/**
 * SleuthSpanInjector to inject a custom HTTP header for the Sleuth traceId
 */
public class SleuthSpanInjector implements SpanInjector<HttpServletResponse> {

    private String traceIdHeaderName;
    private static final Logger logger = LoggerFactory.getLogger(SleuthSpanInjector.class);

    SleuthSpanInjector(String traceIdHeaderName) {
        this.traceIdHeaderName = traceIdHeaderName;
    }

    @Override
    public void inject(Span span, HttpServletResponse carrier) {

        String traceId = Span.idToHex(span.getTraceId());
        logger.debug("Set traceId header: '{}' to '{}'", traceIdHeaderName, traceId);
        carrier.addHeader(traceIdHeaderName, traceId);
    }
}
