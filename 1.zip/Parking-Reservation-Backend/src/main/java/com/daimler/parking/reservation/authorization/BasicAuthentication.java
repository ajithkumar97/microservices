package com.daimler.parking.reservation.authorization;

import org.apache.commons.codec.binary.Base64;

/**
 * Reusable class for storing basic authentication data.
 * Provides the base64 String representation for username and password.
 */
public class BasicAuthentication {

    private String user;
    private String password;
    private boolean enabled;

    /**
     * Default ctor.
     */
    public BasicAuthentication() {
        // default ctor
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the base64 encoded basic authentication string for e.g. usage in HTTP Header
     *
     * @return Base64 encoded string generated from username and password.
     */
    public String getBase64BasicAuthString() {
        final String userPassword = this.user + ":" + this.password;
        final byte[] userPwBytes = userPassword.getBytes();
        final byte[] base64Bytes = Base64.encodeBase64(userPwBytes);
        return new String(base64Bytes);
    }

}
