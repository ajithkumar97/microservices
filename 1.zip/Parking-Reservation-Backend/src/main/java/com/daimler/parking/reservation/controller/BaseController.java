package com.daimler.parking.reservation.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.exceptions.handler.data.ErrorCode;
import com.daimler.parking.reservation.exceptions.handler.data.ErrorObject;

@Component
public class BaseController {
	
public List<ErrorObject> setParameterMissingError(String parameter) {
		
		List<ErrorObject> errorObjectList = new ArrayList<>();
        ErrorObject errorObject = new ErrorObject(ErrorCode.MISSING_PARAMETER, parameter+ " is  Missing");
        errorObjectList.add(errorObject);

		return errorObjectList;
	}

	public List<ErrorObject> setPayLoadMissingError(String parameter) {
		
		List<ErrorObject> errorObjectList = new ArrayList<>();
        ErrorObject errorObject = new ErrorObject(ErrorCode.MISSING_PAYLOAD, parameter+ " is  Missing");
        errorObjectList.add(errorObject);

		return errorObjectList;
	}

}
