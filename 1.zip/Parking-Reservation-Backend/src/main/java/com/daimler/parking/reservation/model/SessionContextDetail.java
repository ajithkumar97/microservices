package com.daimler.parking.reservation.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SessionContextDetail implements Serializable {

	@JsonProperty("SessionStart")
	private String sessionStart;
	
	@JsonProperty("SessionEnd")
	private String sessionEnd;
	
	@JsonProperty("SessionID")	
	private String sessionID;
	
	@JsonProperty("Car")
	private Car car;
	
	@JsonProperty("CurrentUser")
	private CurrentUser currentUser;

	public String getSessionStart() {
		return sessionStart;
	}

	public void setSessionStart(String sessionStart) {
		this.sessionStart = sessionStart;
	}

	public String getSessionEnd() {
		return sessionEnd;
	}

	public void setSessionEnd(String sessionEnd) {
		this.sessionEnd = sessionEnd;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public CurrentUser getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(CurrentUser currentUser) {
		this.currentUser = currentUser;
	}

	@Override
	public String toString() {
		return "SessionContextDetail [sessionStart=" + sessionStart + ", sessionEnd=" + sessionEnd + ", sessionID="
				+ sessionID + ", car=" + car + ", currentUser=" + currentUser + "]";
	}

	
	
}
