package com.daimler.parking.reservation.request;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.daimler.parking.reservation.response.BookingDetails;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ParkingTransactionRequest extends BaseRequest implements Serializable{
	
	private static final long serialVersionUID = 611838699138105348L;
	
	@ApiModelProperty(value = "bookingDetails", readOnly = true)
	@JsonProperty("bookingDetails")
	@NotEmpty(message = "results cannot be blank.")
	private BookingDetails bookingDetails;
	
	@ApiModelProperty(value = "notificationId", readOnly = true)
	@JsonProperty("notificationId")
	@NotEmpty(message = "notificationId cannot be blank.")
	private String notificationId;
	
	@ApiModelProperty(value = "txnID", readOnly = true)
	@JsonProperty("txnID")
	@NotEmpty(message = "txnID cannot be blank.")
	private String txnID;
	
	@ApiModelProperty(value = "serviceProvider", readOnly = true)
	@JsonProperty("serviceProvider")
	@NotEmpty(message = "serviceProvider cannot be blank.")
	private String serviceProvider;
	
	private String cancelledAt;

	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}

	public void setBookingResponse(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public String getTxnID() {
		return txnID;
	}

	public void setTxnID(String txnID) {
		this.txnID = txnID;
	}

	public String getCancelledAt() {
		return cancelledAt;
	}

	public void setCancelledAt(String cancelledAt) {
		this.cancelledAt = cancelledAt;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

    @Override
    public String toString() {
        return "ParkingTransactionRequest [bookingDetails=" + bookingDetails + ", notificationId=" + notificationId + ", txnID=" + txnID
                + ", serviceProvider=" + serviceProvider + ", cancelledAt=" + cancelledAt + "]";
    }
	
	
	
}
