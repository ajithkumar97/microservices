package com.daimler.parking.reservation.monitoring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.sleuth.Span;
import org.springframework.cloud.sleuth.SpanExtractor;

import javax.servlet.http.HttpServletRequest;

/**
 * SleuthSpanExtractor to extract the Sleuth traceId from a custom HTTP header
 */
class SleuthSpanExtractor implements SpanExtractor<HttpServletRequest> {

    private String traceIdHeaderName;
    private static final Logger logger = LoggerFactory.getLogger(SleuthSpanExtractor.class);

    SleuthSpanExtractor(String traceIdHeaderName) {
        this.traceIdHeaderName = traceIdHeaderName;
    }

    @Override
    public Span joinTrace(HttpServletRequest request) {
        String traceId = request.getHeader(traceIdHeaderName);

        if (null != traceId) {
            logger.debug("Received trace-id in HTTP header: '{}': '{}'", traceIdHeaderName, traceId);
            Span.SpanBuilder builder = Span.builder();
            try {
                builder.traceId(Span.hexToId(traceId));
                return builder.build();
            } catch (NumberFormatException ex) {
                logger.warn("Received invalid trace-id in HTTP header: '{}'. Trace-id must be a valid number in hexadecimal string notation: '{}'. Creating new one...", traceId);
                return null;
            }
        } else {
            logger.debug("No traceId received as HTTP header: '{}', creating new one...", traceIdHeaderName);
            return null;
        }
    }
}
