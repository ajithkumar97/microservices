package com.daimler.parking.reservation.response;

public class ParkingOffenderResponse extends BaseResponse {
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
