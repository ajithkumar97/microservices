package com.daimler.parking.reservation.mapping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.Image;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.utils.EncryptionUtils;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class ParkingSpaceDeserializer extends JsonDeserializer<ParkingSlot> {

	private static final String DATA_NODE = "data";
	private static final String META_NODE = "meta";
	
	private static AmpidoAdapter ampidoAdapter;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ParkingSpaceDeserializer.class);
	
	public ParkingSpaceDeserializer()
	{
		
	}
	@Autowired
	public ParkingSpaceDeserializer(AmpidoAdapter ampidoAdapter)
	{
		this.ampidoAdapter=ampidoAdapter;
	}
	


	@Override
	public ParkingSlot deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {

		JsonNode rootNode = p.getCodec().readTree(p);
		JsonNode dataNode = rootNode.path(DATA_NODE);
		JsonNode metaNode = rootNode.path(META_NODE);
		ParkingSlot currentParkingSpace = new ParkingSlot();

		currentParkingSpace.setFreeUntil(dataNode.path("freeUntil").asText());
		currentParkingSpace.setPriceDetails(dataNode.path("priceDetails").asText());
		currentParkingSpace.setPriceTotal(dataNode.path("priceTotal").asText());
		currentParkingSpace.setParkingSpaceId(dataNode.path("uuid").asText());
		currentParkingSpace.setDescription(dataNode.path("description").asText());
		currentParkingSpace.setAccessMethod(dataNode.path("accessMethod").asText());
		currentParkingSpace.setImportantInformation(dataNode.path("importantInformation").asText());
		JsonNode exclusivesNode = dataNode.path("exclusiveFor");
		currentParkingSpace.setLatitude(dataNode.path("latitude").asDouble());
		currentParkingSpace.setLongitude(dataNode.path("longitude").asDouble());
		currentParkingSpace.setCountry(dataNode.path("country").asText());
		currentParkingSpace.setCity(dataNode.path("city").asText());
		currentParkingSpace.setPostalCode(dataNode.path("postalCode").asText());
		currentParkingSpace.setStreetName(dataNode.path("streetName").asText());
		currentParkingSpace.setAccessRestriction(dataNode.path("accessRestriction").asText());
		JsonNode imagesNode = dataNode.path("images");
		currentParkingSpace.setStreetNumber(dataNode.path("streetNumber").asText());
		currentParkingSpace.setUpdatedAt(dataNode.path("updatedAt").asText());
		JsonNode featuresNode = dataNode.path("features");
		JsonNode typeNode = dataNode.path("type");
		JsonNode priceBreakupNode = dataNode.path("priceBreakup");
		
		if (imagesNode.isArray()) {
			List<Image> images = null;
			try {
				images = extractImages(imagesNode);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			currentParkingSpace.setImages(images);
		}
		if (featuresNode.isArray()) {
			List<Feature> features = extractFeatures(featuresNode);
			currentParkingSpace.setFeatures(features);
		}
		if (exclusivesNode.isArray()) {
			List<String> exclusives = extractExclusives(exclusivesNode);
			currentParkingSpace.setExclusiveFor(exclusives);
		}
		if (typeNode.isArray()) {
			List<String> type = extractType(typeNode);
			currentParkingSpace.setType(type);
		}
		if (priceBreakupNode.isArray()) {
			List<String> priceBreakup = extractType(priceBreakupNode);
			currentParkingSpace.setPriceBreakup(priceBreakup);
		}

		currentParkingSpace.setCompany(metaNode.path("company").asText());
		currentParkingSpace.setLogoUrl(metaNode.path("logoUrl").asText());

		return currentParkingSpace;
	}

	private List<String> extractType(JsonNode typeNode) {

		List<String> type = new ArrayList<>();
		for (JsonNode exclusiveNode : typeNode) {
			type.add(exclusiveNode.asText());
		}

		return type;
	}

	private List<Image> extractImages(JsonNode imagesNode) throws Exception {
		
		String url = null;
		List<Image> images = new ArrayList<>();

		for (JsonNode imageNode : imagesNode) {
			Image image = new Image();
			 url = imageNode.path("url").asText();
			/*final String encryptedURL = CommonUtils.encryptText(url);
			LOGGER.info("----Inside encrytion-----"+encryptedURL);*/
			image.setUrl(ampidoAdapter.getImageURL(url));
			image.setType(imageNode.path("type").asText());
			images.add(image);
		}
		return images;
	}

	private List<Feature> extractFeatures(JsonNode featuresNode) {

		List<Feature> features = new ArrayList<>();
		for (JsonNode featureNode : featuresNode) {
			Feature feature = new Feature();
			feature.setId(featureNode.path("id").asText());
			feature.setName(featureNode.path("name").asText());
			features.add(feature);
		}
		return features;
	}

	private List<String> extractExclusives(JsonNode exclusivesNode) {

		List<String> exclusives = new ArrayList<>();
		for (JsonNode exclusiveNode : exclusivesNode) {
			exclusives.add(exclusiveNode.asText());
		}

		return exclusives;
	}

}
