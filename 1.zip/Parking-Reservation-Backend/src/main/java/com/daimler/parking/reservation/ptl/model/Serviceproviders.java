package com.daimler.parking.reservation.ptl.model;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
public class Serviceproviders {

    @JsonProperty("contactInformation")
    private String contactInformation;
    @JsonProperty("corporateForm")
    private String corporateForm;
    @JsonProperty("name")
    private String name;

    @JsonProperty("contactInformation")
    public String getContactInformation() {
        return contactInformation;
    }

    @JsonProperty("contactInformation")
    public void setContactInformation(String contactInformation) {
        this.contactInformation = contactInformation;
    }

    @JsonProperty("corporateForm")
    public String getCorporateForm() {
        return corporateForm;
    }

    @JsonProperty("corporateForm")
    public void setCorporateForm(String corporateForm) {
        this.corporateForm = corporateForm;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

}
