package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "c2cUrls", ignoreUnknownFields = false)
public class C2crUrlProperties {
	
	private String parkingSpaceDetailsUrl;

	public String getParkingSpaceDetailsUrl() {
		return parkingSpaceDetailsUrl;
	}

	public void setParkingSpaceDetailsUrl(String parkingSpaceDetailsUrl) {
		this.parkingSpaceDetailsUrl = parkingSpaceDetailsUrl;
	}

}
