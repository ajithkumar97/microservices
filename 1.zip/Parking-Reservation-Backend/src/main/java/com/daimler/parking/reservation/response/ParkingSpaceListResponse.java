package com.daimler.parking.reservation.response;

import java.util.List;

import com.daimler.parking.reservation.mapping.AmpidoDeserializer;
import com.daimler.parking.reservation.model.ParkingSpace;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(using=AmpidoDeserializer.class)
public class ParkingSpaceListResponse extends BaseResponse {
	
	private List<ParkingSpace> ParkingSpaces;

	public List<ParkingSpace> getParkingSpaces() {
		return ParkingSpaces;
	}

	public void setParkingSpaces(List<ParkingSpace> parkingSpaces) {
		ParkingSpaces = parkingSpaces;
	}


}
