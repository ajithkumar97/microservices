package com.daimler.parking.reservation.mapping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.model.Barrier;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.Image;
import com.daimler.parking.reservation.model.Slot;
import com.daimler.parking.reservation.model.Type;
import com.daimler.parking.reservation.response.BookingResponse;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class BookingResponseDeserializer extends JsonDeserializer<BookingResponse> {

	private static final String RENT_NODE = "rent";
	private static final String META_NODE = "meta";

	private static AmpidoAdapter ampidoAdapter;

	private static final Logger LOGGER = LoggerFactory.getLogger(BookingResponseDeserializer.class);

	public BookingResponseDeserializer() {

	}

	@Autowired
	public BookingResponseDeserializer(AmpidoAdapter ampidoAdapter) {
		this.ampidoAdapter = ampidoAdapter;
	}

	@Override
	public BookingResponse deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {

		LOGGER.info("Deserializing Booking Response from Ampido");
		JsonNode rootNode = p.getCodec().readTree(p);

		JsonNode rentNode = rootNode.path(RENT_NODE);
		JsonNode metaNode = rootNode.path(META_NODE);

		BookingResponse bookingResponse = new BookingResponse();

		bookingResponse.setUuid(rentNode.path("uuid").asText());
		bookingResponse.setExternalUuid(rentNode.path("externalUuid").asText());
		bookingResponse.setStartTime(rentNode.path("startTime").asText());
		bookingResponse.setEndTime(rentNode.path("endTime").asText());
		bookingResponse.setLicencePlate(rentNode.path("licencePlate").asText());
		bookingResponse.setCancelledAt(rentNode.path("cancelledAt").asText());
		bookingResponse.setSecretInformation(rentNode.path("secretInformation").asText());
		JsonNode barriersNode = rentNode.path("barriers");

		if (barriersNode.isArray()) {
			List<Barrier> barriers = extractBarriers(barriersNode);
			bookingResponse.setBarriers(barriers);
		}
		
			JsonNode slotNode = rentNode.path("slot");
			Slot slot = new Slot();
			slot.setUuid(slotNode.path("uuid").asText());
			slot.setDescription(slotNode.path("description").asText());
			slot.setAccessRestriction(slotNode.path("accessRestriction").asText());
			JsonNode imageNode = slotNode.path("images");
			slot.setAccessMethod(slotNode.path("accessMethod").asText());
			slot.setImportantInformation(slotNode.path("importantInformation").asText());
			JsonNode exclusivesNode = slotNode.path("exclusiveFor");
			slot.setLatitude(slotNode.path("latitude").asDouble());
			slot.setLongitude(slotNode.path("longitude").asDouble());
			slot.setCountry(slotNode.path("country").asText());
			slot.setCity(slotNode.path("city").asText());
			slot.setPostalCode(slotNode.path("postalCode").asText());
			slot.setStreetName(slotNode.path("streetName").asText());
			slot.setStreetNumber(slotNode.path("streetNumber").asText());
			slot.setUpdatedAt(slotNode.path("updatedAt").asText());
			JsonNode featuresNode = slotNode.path("features");
			JsonNode typeNode = slotNode.path("type");

			if (imageNode.isArray()) {
				List<Image> images = null;
				try {
					images = extractImages(imageNode);
				} catch (Exception e) {
					e.printStackTrace();
				}
				slot.setImages(images);
			}
			if (featuresNode.isArray()) {
				List<Feature> features = extractFeatures(featuresNode);
				slot.setFeatures(features);
			}
			if (exclusivesNode.isArray()) {
				List<String> exclusives = extractExclusives(exclusivesNode);
				slot.setExclusiveFor(exclusives);
			}
		Type type = extractType(typeNode);
		slot.setType(type);
		
		bookingResponse.setSlot(slot);
		bookingResponse.setCompany(metaNode.path("company").asText());
		bookingResponse.setLogoUrl(metaNode.path("logoUrl").asText());

		return bookingResponse;
	}

	private Type extractType(JsonNode typeNode) {
		Type type = new Type();
		type.setId(typeNode.path("id").asText());
		type.setName(typeNode.path("name").asText());
		return type;
	}

	private List<String> extractExclusives(JsonNode exclusivesNode) {

		List<String> exclusives = new ArrayList<>();
		for (JsonNode exclusiveNode : exclusivesNode) {
			exclusives.add(exclusiveNode.asText());
		}

		return exclusives;
	}

	private List<Feature> extractFeatures(JsonNode featuresNode) {

		List<Feature> features = new ArrayList<>();
		for (JsonNode featureNode : featuresNode) {
			Feature feature = new Feature();
			feature.setId(featureNode.path("id").asText());
			feature.setName(featureNode.path("name").asText());
			features.add(feature);
		}
		return features;

	}

	private List<Image> extractImages(JsonNode imagesNode) throws Exception {

		String url = null;
		List<Image> images = new ArrayList<>();

		for (JsonNode imageNode : imagesNode) {
			Image image = new Image();
			url = imageNode.path("url").asText();
			image.setUrl(ampidoAdapter.getImageURL(url));
			image.setType(imageNode.path("type").asText());
			images.add(image);
		}
		return images;
	}

	private List<Barrier> extractBarriers(JsonNode barriersNode) {
		List<Barrier> barriers = new ArrayList<>();
		for (JsonNode barrierNode : barriersNode) {
			Barrier barrier = new Barrier();
			barrier.setUuid(barrierNode.path("uuid").asText());
			barrier.setPosition(barrierNode.path("position").asText());
			barriers.add(barrier);
		}
		return barriers;
	}

}
