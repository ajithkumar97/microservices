package com.daimler.parking.reservation.ptl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Address {

    @JsonProperty("buildingNo")
    private String buildingNo;
    @JsonProperty("city")
    private String city;
    @JsonProperty("country")
    private String country;
    @JsonProperty("state")
    private String state;
    @JsonProperty("street")
    private String street;
    @JsonProperty("zipCode")
    private String zipCode;

    @JsonProperty("buildingNo")
    public String getBuildingNo() {
        return buildingNo;
    }

    @JsonProperty("buildingNo")
    public void setBuildingNo(String buildingNo) {
        this.buildingNo = buildingNo;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("street")
    public String getStreet() {
        return street;
    }

    @JsonProperty("street")
    public void setStreet(String street) {
        this.street = street;
    }

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

}
