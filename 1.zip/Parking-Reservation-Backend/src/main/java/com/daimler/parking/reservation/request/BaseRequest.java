package com.daimler.parking.reservation.request;

public class BaseRequest {

}
