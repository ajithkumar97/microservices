package com.daimler.parking.reservation.model;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.daimler.parking.reservation.mapping.ParkingSpaceDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(using=ParkingSpaceDeserializer.class)
public class ParkingSlot{
	
	@NotEmpty(message = "ParkingSpaceId cannot be blank.")
	private String parkingSpaceId;
	
	@NotEmpty(message = "latitude cannot be blank.")
	private double latitude;

	@NotEmpty(message = "longitude cannot be blank.")
	private double longitude;
	
	private String priceDetails;
	
	private List<String> priceBreakup;
	
	private String priceTotal;

	private String freeUntil;

	@NotEmpty(message = "accessRestriction cannot be blank.")
	private String accessRestriction;

	@NotEmpty(message = "accessMethod cannot be blank.")
	private String accessMethod;

	@NotEmpty(message = "importantInformation cannot be blank.")
	private String importantInformation;

	@NotEmpty(message = "description cannot be blank.")
	private String description;

	@NotEmpty(message = "type cannot be blank.")
	private List<String> type;
	
	@NotEmpty(message = "features cannot be blank.")
	private List<Feature> features;

	@NotEmpty(message = "images cannot be blank.")
	private List<Image> images;

	@NotEmpty(message = "exclusiveFor cannot be blank.")
	private List<String> exclusiveFor;

	@NotEmpty(message = "country cannot be blank.")
	private String country;

	@NotEmpty(message = "city cannot be blank.")
	private String city;

	@NotEmpty(message = "streetName cannot be blank.")
	private String streetName;

	@NotEmpty(message = "postalCode cannot be blank.")
	private String postalCode;

	@NotEmpty(message = "streetNumber cannot be blank.")
	private String streetNumber;
	
	private String updatedAt;
	
	private String company;
	
	@JsonIgnore
	private String logoUrl;
	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getLogoUrl() {
		return logoUrl;
	}

	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

	public List<String> getType() {
		return type;
	}

	public void setType(List<String> type) {
		this.type = type;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getParkingSpaceId() {
		return parkingSpaceId;
	}

	public void setParkingSpaceId(String parkingSpaceId) {
		this.parkingSpaceId = parkingSpaceId;
	}

	public String getPriceDetails() {
		return priceDetails;
	}

	public void setPriceDetails(String priceDetails) {
		this.priceDetails = priceDetails;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getPriceTotal() {
		return priceTotal;
	}

	public void setPriceTotal(String priceTotal) {
		this.priceTotal = priceTotal;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public List<String> getExclusiveFor() {
		return exclusiveFor;
	}

	public void setExclusiveFor(List<String> exclusiveFor) {
		this.exclusiveFor = exclusiveFor;
	}

	public String getImportantInformation() {
		return importantInformation;
	}

	public void setImportantInformation(String importantInformation) {
		this.importantInformation = importantInformation;
	}

	public String getAccessMethod() {
		return accessMethod;
	}

	public void setAccessMethod(String accessMethod) {
		this.accessMethod = accessMethod;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Feature> getFeatures() {
		return features;
	}

	public void setFeatures(List<Feature> features) {
		this.features = features;
	}

	public List<Image> getImages() {
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public String getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}


	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getAccessRestriction() {
		return accessRestriction;
	}

	public void setAccessRestriction(String accessRestriction) {
		this.accessRestriction = accessRestriction;
	}
	
	public String getFreeUntil() {
		return freeUntil;
	}

	public void setFreeUntil(String freeUntil) {
		this.freeUntil = freeUntil;
	}

	public List<String> getPriceBreakup() {
		return priceBreakup;
	}

	public void setPriceBreakup(List<String> priceBreakup) {
		this.priceBreakup = priceBreakup;
	}

	@Override
	public String toString() {
		return "ParkingSlot [parkingSpaceId=" + parkingSpaceId + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", priceDetails=" + priceDetails + ", priceBreakup=" + priceBreakup + ", priceTotal=" + priceTotal
				+ ", freeUntil=" + freeUntil + ", accessRestriction=" + accessRestriction + ", accessMethod="
				+ accessMethod + ", importantInformation=" + importantInformation + ", description=" + description
				+ ", type=" + type + ", features=" + features + ", images=" + images + ", exclusiveFor=" + exclusiveFor
				+ ", country=" + country + ", city=" + city + ", streetName=" + streetName + ", postalCode="
				+ postalCode + ", streetNumber=" + streetNumber + ", updatedAt=" + updatedAt + ", company=" + company
				+ ", logoUrl=" + logoUrl + "]";
	}

	

}
