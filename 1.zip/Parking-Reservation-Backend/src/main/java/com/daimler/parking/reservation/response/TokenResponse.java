package com.daimler.parking.reservation.response;

import org.hibernate.validator.constraints.NotEmpty;

public class TokenResponse  extends BaseResponse{

	@NotEmpty(message="accesToken can not be empty")
	private String access_token;
	@NotEmpty(message="refreshToken can not be empty")
	private String refresh_token;
	private String token_type;
	@NotEmpty(message="expiresIn can not be empty")
	private int expires_in;
	private String scope;
	private int created_at;
	
	
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getToken_type() {
		return token_type;
	}
	public void setToken_type(String token_type) {
		this.token_type = token_type;
	}
	public int getExpires_in() {
		return expires_in;
	}
	public void setExpires_in(int expires_in) {
		this.expires_in = expires_in;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public int getCreated_at() {
		return created_at;
	}
	public void setCreated_at(int created_at) {
		this.created_at = created_at;
	}
	
	public String getRefresh_token() {
		return refresh_token;
	}
	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}
	@Override
	public String toString() {
		return "TokenResponse [access_token=" + access_token + ", token_type=" + token_type + ", expires_in="
				+ expires_in + ", scope=" + scope + ", created_at=" + created_at + "]";
	}


}
