package com.daimler.parking.reservation.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.daimler.parking.reservation.authorization.AuthorizationInterceptor;


@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    @Autowired
    private AuthorizationInterceptor authorizationInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        super.addInterceptors(registry);
        //Add Authorization Interceptor
        InterceptorRegistration interceptorReg = registry.addInterceptor(authorizationInterceptor);
        interceptorReg.addPathPatterns("/parkingreservation/v1", "/parkingreservation/v1/*");
    }
}

