package com.daimler.parking.reservation.ptl.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Parkingspace {

    @JsonProperty("accessMethod")
    private String accessMethod;
    @JsonProperty("accessRestriction")
    private String accessRestriction;
    @JsonProperty("description")
    private String description;
    @JsonProperty("externalUuid")
    private String externalUuid;
    @JsonProperty("features")
    private String features;
    @JsonProperty("importantInformation")
    private String importantInformation;
    @JsonProperty("latitude")
    private Double latitude;
    @JsonProperty("longitude")
    private Double longitude;
    @JsonProperty("parkingspacebarrier")
    private Parkingspacebarrier parkingspacebarrier;
    @JsonProperty("parkingspaceimages")
    private Parkingspaceimages parkingspaceimages;
    @JsonProperty("type")
    private String type;

    @JsonProperty("accessMethod")
    public String getAccessMethod() {
        return accessMethod;
    }

    @JsonProperty("accessMethod")
    public void setAccessMethod(String accessMethod) {
        this.accessMethod = accessMethod;
    }

    @JsonProperty("accessRestriction")
    public String getAccessRestriction() {
        return accessRestriction;
    }

    @JsonProperty("accessRestriction")
    public void setAccessRestriction(String accessRestriction) {
        this.accessRestriction = accessRestriction;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("externalUuid")
    public String getExternalUuid() {
        return externalUuid;
    }

    @JsonProperty("externalUuid")
    public void setExternalUuid(String externalUuid) {
        this.externalUuid = externalUuid;
    }

    @JsonProperty("features")
    public String getFeatures() {
        return features;
    }

    @JsonProperty("features")
    public void setFeatures(String features) {
        this.features = features;
    }

    @JsonProperty("importantInformation")
    public String getImportantInformation() {
        return importantInformation;
    }

    @JsonProperty("importantInformation")
    public void setImportantInformation(String importantInformation) {
        this.importantInformation = importantInformation;
    }

    @JsonProperty("latitude")
    public Double getLatitude() {
        return latitude;
    }

    @JsonProperty("latitude")
    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    @JsonProperty("longitude")
    public Double getLongitude() {
        return longitude;
    }

    @JsonProperty("longitude")
    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    @JsonProperty("parkingspacebarrier")
    public Parkingspacebarrier getParkingspacebarrier() {
        return parkingspacebarrier;
    }

    @JsonProperty("parkingspacebarrier")
    public void setParkingspacebarrier(Parkingspacebarrier parkingspacebarrier) {
        this.parkingspacebarrier = parkingspacebarrier;
    }

    @JsonProperty("parkingspaceimages")
    public Parkingspaceimages getParkingspaceimages() {
        return parkingspaceimages;
    }

    @JsonProperty("parkingspaceimages")
    public void setParkingspaceimages(Parkingspaceimages parkingspaceimages) {
        this.parkingspaceimages = parkingspaceimages;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

}
