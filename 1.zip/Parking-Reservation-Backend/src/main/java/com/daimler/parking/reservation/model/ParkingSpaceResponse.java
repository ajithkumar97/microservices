package com.daimler.parking.reservation.model;

import com.daimler.parking.reservation.mapping.ParkingSpaceDeserializer;
import com.daimler.parking.reservation.response.BaseResponse;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(using=ParkingSpaceDeserializer.class)
public class ParkingSpaceResponse extends BaseResponse {

	private ParkingSlot parkingSpace;
	
	private String logoUrl;
	
	public String getLogoUrl() {
		return logoUrl;
	}

	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

	public ParkingSlot getParkingSpace() {
		return parkingSpace;
	}

	public void setParkingSpace(ParkingSlot parkingSpace) {
		this.parkingSpace = parkingSpace;
	}

	

}
