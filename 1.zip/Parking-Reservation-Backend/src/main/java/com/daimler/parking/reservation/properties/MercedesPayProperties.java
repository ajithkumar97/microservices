package com.daimler.parking.reservation.properties;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(ignoreUnknownFields = false, prefix = "mercedespay")
public class MercedesPayProperties {

	@NotNull
	private String mercedesPaymentUrl;
	
	@NotNull
	private String trustStorePath;

	public String getMercedesPaymentUrl() {
		return mercedesPaymentUrl;
	}

	public void setMercedesPaymentUrl(String mercedesPaymentUrl) {
		this.mercedesPaymentUrl = mercedesPaymentUrl;
	}

	public String getTrustStorePath() {
		return trustStorePath;
	}

	public void setTrustStorePath(String trustStorePath) {
		this.trustStorePath = trustStorePath;
	}

}
