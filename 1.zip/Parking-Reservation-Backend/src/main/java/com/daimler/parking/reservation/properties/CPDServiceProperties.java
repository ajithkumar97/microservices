package com.daimler.parking.reservation.properties;

import javax.validation.constraints.NotNull;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.authorization.BasicAuthentication;

@Component
@ConfigurationProperties(ignoreUnknownFields = false, prefix = "cpdservice")
public class CPDServiceProperties {
	@NotNull
	private String userUrl;
/*	@NotNull
	private String userIdUrl;*/
	@NotNull
	private String appName;
	@NotNull
	private BasicAuthentication basicAuth;
/*	@NotNull
	private String authorizeduser;
	@NotNull
	private String authorizedpwd;
	@NotNull
	private String headername;
	@NotNull
	private String headerpwd;*/
	@NotNull
	private String pfxPath;
	@NotNull
	private String certPassword;
	@NotNull
	private String trustStorePath;

	public String getUserUrl() {
		return userUrl;
	}

	public void setUserUrl(String userUrl) {
		this.userUrl = userUrl;
	}

/*	public String getUserIdUrl() {
		return userIdUrl;
	}

	public void setUserIdUrl(String userIdUrl) {
		this.userIdUrl = userIdUrl;
	}*/

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public BasicAuthentication getBasicAuth() {
		return basicAuth;
	}

	public void setBasicAuth(BasicAuthentication basicAuth) {
		this.basicAuth = basicAuth;
	}

	public String getPfxPath() {
		return pfxPath;
	}

	public void setPfxPath(String pfxPath) {
		this.pfxPath = pfxPath;
	}

	public String getTrustStorePath() {
		return trustStorePath;
	}

	public void setTrustStorePath(String trustStorePath) {
		this.trustStorePath = trustStorePath;
	}

	public String getCertPassword() {
		return certPassword;
	}

	public void setCertPassword(String certPassword) {
		this.certPassword = certPassword;
	}

/*	public String getAuthorizeduser() {
		return authorizeduser;
	}

	public void setAuthorizeduser(String authorizeduser) {
		this.authorizeduser = authorizeduser;
	}

	public String getAuthorizedpwd() {
		return authorizedpwd;
	}

	public void setAuthorizedpwd(String authorizedpwd) {
		this.authorizedpwd = authorizedpwd;
	}

	public String getHeadername() {
		return headername;
	}

	public void setHeadername(String headername) {
		this.headername = headername;
	}

	public String getHeaderpwd() {
		return headerpwd;
	}

	public void setHeaderpwd(String headerpwd) {
		this.headerpwd = headerpwd;
	}*/

}
