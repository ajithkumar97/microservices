
package com.daimler.parking.reservation.mapping;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.model.ParkingSpace;
import com.daimler.parking.reservation.properties.C2crUrlProperties;
import com.daimler.parking.reservation.response.ParkingSpaceListResponse;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class AmpidoDeserializer extends JsonDeserializer<ParkingSpaceListResponse> {

	private static C2crUrlProperties c2crUrlProperties;

	//For jackson initialization
	public AmpidoDeserializer(){};

	@Autowired
	public AmpidoDeserializer(C2crUrlProperties c2crUrlProperties) {
		this.c2crUrlProperties = c2crUrlProperties;
	}

	private static final String DATA_NODE = "data";
	private static final String META_NODE = "meta";


	@Override
	public ParkingSpaceListResponse deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {

		JsonNode rootNode = jp.getCodec().readTree(jp);

		ParkingSpaceListResponse parkingResponse = new ParkingSpaceListResponse();
		JsonNode dataNode = rootNode.path(DATA_NODE);
		List<ParkingSpace> ParkingSpaces =  new ArrayList<>();

		if(dataNode.isArray()){
			for(JsonNode parkingSpaceNode : dataNode){
				String startTime,endTime;
				ParkingSpace currentParkingSpace = new ParkingSpace();
				
				currentParkingSpace.setParkingSpaceId(
						(parkingSpaceNode.path("uuid").isNull())?"":parkingSpaceNode.path("uuid").asText());
				currentParkingSpace.setLatitude(parkingSpaceNode.path("latitude").asDouble());
				currentParkingSpace.setLongitude(parkingSpaceNode.path("longitude").asDouble());
				currentParkingSpace.setCountry("DEU");
				currentParkingSpace.setCity(
						(parkingSpaceNode.path("city").isNull())?"":parkingSpaceNode.path("city").asText());
				currentParkingSpace.setPostalCode(
						(parkingSpaceNode.path("postalCode").isNull())?"":parkingSpaceNode.path("postalCode").asText());
				currentParkingSpace.setStreetName(
						(parkingSpaceNode.path("streetName").isNull())?"":parkingSpaceNode.path("streetName").asText());
				currentParkingSpace.setStreetNumber(
						(parkingSpaceNode.path("streetNumber").isNull())?"":parkingSpaceNode.path("streetNumber").asText());
			
				startTime = rootNode.path(META_NODE).path("startTime").asText();
				if(parkingSpaceNode.path("freeUntil").isNull())
							 endTime = rootNode.path(META_NODE).path("endTime").asText();			
				else
							 endTime = parkingSpaceNode.path("freeUntil").asText();
	
				currentParkingSpace.setDetailsUrl(c2crUrlProperties.getParkingSpaceDetailsUrl()+parkingSpaceNode.path("uuid").asText()
						+"?startTime="+startTime+"&endTime="+endTime);
				ParkingSpaces.add(currentParkingSpace);
			}
		}
		parkingResponse.setParkingSpaces(ParkingSpaces);
		return parkingResponse;
	}
}
