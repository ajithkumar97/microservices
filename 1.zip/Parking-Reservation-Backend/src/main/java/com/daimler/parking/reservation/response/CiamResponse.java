package com.daimler.parking.reservation.response;

public class CiamResponse {
	
	private String assetStatus;

	public String getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}

	@Override
	public String toString() {
		return "CiamResponse [assetStatus=" + assetStatus + "]";
	}
	
	

}
