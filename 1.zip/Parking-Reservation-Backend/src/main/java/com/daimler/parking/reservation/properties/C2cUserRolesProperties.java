/**
 * Copyright 2017 Mercedes Benz Research & Development, A Daimler Company. All rights reserved.
 */

package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author avasuku
 *
 */
@Component
@ConfigurationProperties(prefix = "roleCredentials", ignoreUnknownFields = false)
public class C2cUserRolesProperties {

    private String ntgUser;
    private String ntgmanager;
    private String mmaUser;
    private String mmamanager;
    private String mmcpUser;
    private String mmcpManager;
    private String supportUser;
    private String supportManager;
    private String ampidoUser;

    private String ntgUserPwd;
    private String mmaUserPwd;
    private String mmcpUserPwd;
    private String supportUserPwd;
    private String ampidoUserPwd;

    private String ntgManagerPwd;
    private String mmaManagerPwd;
    private String mmcpManagerPwd;
    private String supportManagerPwd;

    public String getNtgUser() {
        return ntgUser;
    }

    public void setNtgUser(String ntgUser) {
        this.ntgUser = ntgUser;
    }

    public String getNtgmanager() {
        return ntgmanager;
    }

    public void setNtgmanager(String ntgmanager) {
        this.ntgmanager = ntgmanager;
    }

    public String getMmaUser() {
        return mmaUser;
    }

    public void setMmaUser(String mmaUser) {
        this.mmaUser = mmaUser;
    }

    public String getMmamanager() {
        return mmamanager;
    }

    public void setMmamanager(String mmamanager) {
        this.mmamanager = mmamanager;
    }

    public String getMmcpUser() {
        return mmcpUser;
    }

    public void setMmcpUser(String mmcpUser) {
        this.mmcpUser = mmcpUser;
    }

    public String getMmcpManager() {
        return mmcpManager;
    }

    public void setMmcpManager(String mmcpManager) {
        this.mmcpManager = mmcpManager;
    }

    public String getSupportUser() {
        return supportUser;
    }

    public void setSupportUser(String supportUser) {
        this.supportUser = supportUser;
    }

    public String getSupportManager() {
        return supportManager;
    }

    public void setSupportManager(String supportManager) {
        this.supportManager = supportManager;
    }

    public String getAmpidoUser() {
        return ampidoUser;
    }

    public void setAmpidoUser(String ampidoUser) {
        this.ampidoUser = ampidoUser;
    }

    public String getNtgUserPwd() {
        return ntgUserPwd;
    }

    public void setNtgUserPwd(String ntgUserPwd) {
        this.ntgUserPwd = ntgUserPwd;
    }

    public String getMmaUserPwd() {
        return mmaUserPwd;
    }

    public void setMmaUserPwd(String mmaUserPwd) {
        this.mmaUserPwd = mmaUserPwd;
    }

    public String getMmcpUserPwd() {
        return mmcpUserPwd;
    }

    public void setMmcpUserPwd(String mmcpUserPwd) {
        this.mmcpUserPwd = mmcpUserPwd;
    }

    public String getSupportUserPwd() {
        return supportUserPwd;
    }

    public void setSupportUserPwd(String supportUserPwd) {
        this.supportUserPwd = supportUserPwd;
    }

    public String getAmpidoUserPwd() {
        return ampidoUserPwd;
    }

    public void setAmpidoUserPwd(String ampidoUserPwd) {
        this.ampidoUserPwd = ampidoUserPwd;
    }

    public String getNtgManagerPwd() {
        return ntgManagerPwd;
    }

    public void setNtgManagerPwd(String ntgManagerPwd) {
        this.ntgManagerPwd = ntgManagerPwd;
    }

    public String getMmaManagerPwd() {
        return mmaManagerPwd;
    }

    public void setMmaManagerPwd(String mmaManagerPwd) {
        this.mmaManagerPwd = mmaManagerPwd;
    }

    public String getMmcpManagerPwd() {
        return mmcpManagerPwd;
    }

    public void setMmcpManagerPwd(String mmcpManagerPwd) {
        this.mmcpManagerPwd = mmcpManagerPwd;
    }

    public String getSupportManagerPwd() {
        return supportManagerPwd;
    }

    public void setSupportManagerPwd(String supportManagerPwd) {
        this.supportManagerPwd = supportManagerPwd;
    }

}
